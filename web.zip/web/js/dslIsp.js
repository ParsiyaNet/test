﻿var dslIsp = 
{	
	"Armenia":
	{
		"ADSL_Beeline": {dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}
	},
	"Azerbaijan":
	{
		"ADSL_AZSTRNET": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_ALFANET": 	{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_AZERONLINE": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_BAKINTERNET": {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_UNINET": 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}, 
		"ADSL_SUPERONLINE": {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_CONNECT": 	{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"}
	},
	"Argentina":
	{
		"VDSL_Telecom": 			{dslType: "vdsl", vid: "150", connType: "ppp"},
		"VDSL_Telefonica": 		 	{dslType: "vdsl", vid: "20", connType: "ppp"},
		"ADSL_Argentina Telecom": 	{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telefonica Speedy": 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telecom Arnet": 	 	{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"}
	},
	"Australia":
	{
		"VDSL_TransAct": 				 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_NetSpeed": 				 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_CBIT Internet": 				 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_EveryNet": 				 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_IINET": 				 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_Infinite": 				 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_officelink": 				 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_Velocitynet": 				 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"ADSL_aaNet(PPPoE)": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_aaNet(PPPoA)": 			 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_AAPT(PPPoE)": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_AAPT(PPPoA)": 			 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Acenet Internet(PPPoE)": 	 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Acenet Internet(PPPoA)": 	 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Adam Inernet": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Amnet": 					 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Anntel": 					 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_AuNix(PPPoA)": 			 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "LLC"},
		"ADSL_AuNix(PPPoE)": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Aussie Broadband": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Australia On Line": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Beagle Internet": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_ClubTelco(PPPoA)": 		 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "LLC"},
		"ADSL_ClubTelco(PPPoE)": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "VCMUX"},
		"ADSL_DCSI": 					 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Dodo": 					 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Eftel": 					 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_EscapeNet(PPPoA)": 		 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_EScapeNet(PPPoE)": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Exetel": 					 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Hotkey Internet": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_HugoNet(PPPoE)": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_HugoNet(PPPoA)": 			 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_IDXNET": 					 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_iiNet": 					 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Internode(PPPoA)": 		 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Internode(PPPoE)": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_iPrimus(PPPoE)": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_iPrimus(PPPoA)": 			 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_iSage Internet": 			 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Lizzy Internet": 			 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Locall Australis": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Netbay Internet": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Netspace(PPPoE)": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Netspace(PPPoA)": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "VCMUX"},
		"ADSL_OptusNet": 				 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Southern Cross Telco": 	 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telstra(recommend)": 		 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Telstra": 		 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_TPG Internet": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Vintek": 					 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_VoIPex":  				 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Winshop Internet(PPPoE)":  {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Winshop Internet(PPPoA)":  {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Westnet": 				 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_ZettaNet":				 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_SpinTel(PPPoA)": 			 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_SpinTel(PPPoE)": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Austria":
	{
		"VDSL_Telekom": {dslType: "vdsl", vid: "7", connType: "ppp"},
		"ADSL_AON": {dslType: "adsl", pvc: "8/48", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Tiscali": {dslType: "adsl", pvc: "8/48", connType: "pppoa", encapMode: "LLC"},
		"ADSL_UTA": {dslType: "adsl", pvc: "0/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Utanet": {dslType: "adsl", pvc: "8/48", connType: "pppoa", encapMode: "LLC"}
	},
	"Bahrain":
	{
		"ADSL_Batelco":				{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Belgium":
	{
		"ADSL_Belgacom/Skynet": 	{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Scarlet(0/35)": 		{dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Scarlet(5/35)": 		{dslType: "adsl", pvc: "5/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_EDPnet": 				{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Euphony": 			{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "LLC"}
	},
	"Brazil":
	{
		"ADSL_OI ADSL": 					{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}, 
		"ADSL_OI(RS) ADSL": 				{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"}, 
		"ADSL_OI Empresas ADSL": 		 	{dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_OI Empresas(RS) ADSL": 	 	{dslType: "adsl", pvc: "1/32", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Algar NetSuper": 		 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Algar NetSuper-PPPoA": 		{dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_GVT TurboNet ADSL":	 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_OI Velox ADSL": 			 	{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telefonica Speedy": 	 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telefonica Speedy Empresas": 	{dslType: "adsl", pvc: "8/35", connType: "ipoa", encapMode: "LLC"},
		"ADSL_Sercomtel(PPPoE)": 			{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Sercomtel(Static IP)": 		{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"}
	},
	"Brunei Darussalam":
	{
		"ADSL_TelBru e-Speed": {dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"}
	},
	"Cambodia":
	{
		"ADSL_Wicam": 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Online": 		{dslType: "adsl", pvc: "0/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_City Link": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Metfone": 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Camitel": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Angkornet": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Ezecom": 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Mfone": 		{dslType: "adsl", pvc: "38/100", connType: "ppp", encapMode: "LLC"},
		"ADSL_Opennet": 	{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Camnet": 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}
	},
	"Canada":
	{
		"ADSL_Look Communications(I.D.Internet Direct)":		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_iPrimus Canada(west)(Dynamic IP)":				{dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"},
		"ADSL_iPrimus Canada(west)(Static IP)":					{dslType: "adsl", pvc: "0/33", connType: "staip", encapMode: "LLC"},
		"ADSL_iPrimus Canada(east)":							{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telus Quebec":									{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Unitz":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_3WEB(West)(Sybersurf)(Dynamic IP)":				{dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"},
		"ADSL_3WEB(West)(Sybersurf)(Static IP)":				{dslType: "adsl", pvc: "0/33", connType: "staip", encapMode: "LLC"},
		"ADSL_3WEB(east)(Sybersurf)":							{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_MTS(Internet Service Division)-Primus":			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Trytel internet Inc.":							{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Bell Sympatico":									{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telus West(Dynamic IP)":							{dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Telus West(Static IP)":							{dslType: "adsl", pvc: "0/33", connType: "staip", encapMode: "LLC"},
		"ADSL_IGS(Cybersurf)":									{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_LightSpeed Communications(Dynamic IP)":			{dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"},
		"ADSL_LightSpeed Communications(Static IP)":			{dslType: "adsl", pvc: "0/33", connType: "staip", encapMode: "LLC"},
		"ADSL_TekSavvy Solutions":								{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Nucleus Inc(Partner Telus)(Dynamic IP)":			{dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Nucleus Inc(Partner Telus)(Static IP)":			{dslType: "adsl", pvc: "0/33", connType: "staip", encapMode: "LLC"},
		"ADSL_Secure by Designe":								{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_B2B2C":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Fusion Telecom":									{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Can-Net Telecom":									{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_EBTech":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Tbaytel":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_In2net(west)":									{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Inter-Active Telecom":							{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_MySignal":										{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_HyteK(west)":										{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Zid internet":									{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Youmano":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Distributel(east)":								{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Distributel(west)(Dynamic IP)":					{dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Distributel(west)(Static IP)":					{dslType: "adsl", pvc: "0/33", connType: "staip", encapMode: "LLC"},
		"ADSL_Montreal-DSL(east)":								{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Montreal-DSL(west)(Dynamic IP)":					{dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Montreal-DSL(west)(Static IP)":					{dslType: "adsl", pvc: "0/33", connType: "staip", encapMode: "LLC"},
		"ADSL_Netfox":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Velcon":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Acanac":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Electronic Box":									{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Start Communications":							{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_worldline":										{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_connectmoi":										{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Mustang Technologies Inc.":						{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Comwave":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Leopard Networks":								{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Switchworks":										{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_CIKTel":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Storm":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Sunsonic":										{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Vmedia":											{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}		
	},
	"Colombia":
	{
		"ADSL_UNE":				{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_ETP":				{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Edatel":			{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_ETB":				{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Emcali":			{dslType: "adsl", pvc: "0/33", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Telebucaramanga":	{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Metrotel":		{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telefonica":		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}
	},
	"Croatia":
	{
		"VDSL_AMIS": 			{dslType: "vdsl", vid: "0", connType: "ppp"},
		"ADSL_Optima telekom":	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Hrvatski telekom":{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Iskon internet":	{dslType: "adsl", pvc: "0/86", connType: "ppp", encapMode: "LLC"},
		"ADSL_VIP":				{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"}
	},
	"Czech Republic":
	{
		"VDSL_O2": 					{dslType: "vdsl", vid: "848", connType: "ppp"},
		"VDSL_T-Mobile": 			{dslType: "vdsl", vid: "848", connType: "ppp"},
		"ADSL_O2(Czech Republic)": 	{dslType: "adsl", pvc: "8/48", connType: "ppp", encapMode: "LLC"}
	},
	"Denmark":
	{
		"ADSL_Cybercity": {dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "VCMUX"}
	},
	"Dominican Republic":
	{
		"ADSL_Codetel": {dslType: "adsl", pvc: "0/33", connType: "pppoa", encapMode: "VCMUX"}
	},
	"Egypt":
	{
		"ADSL_Etisalat": 				{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_IM": 						{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_LinkdotNet": 				{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Noor ADSL": 				{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_TE-Data": 				{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Vodafone": 				{dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "VCMUX"}
	},
	"Finland":
	{
		"ADSL_Sonera": 			{dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Elisa": 			{dslType: "adsl", pvc: "0/100", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Saunalahti": 		{dslType: "adsl", pvc: "0/100", connType: "dhcp", encapMode: "LLC"},
		"ADSL_DNA": 			{dslType: "adsl", pvc: "0/100", connType: "dhcp", encapMode: "LLC"},
		"ADSL_local operators": {dslType: "adsl", pvc: "0/100", connType: "dhcp", encapMode: "LLC"}
	},
	"France":
	{
		"VDSL_Orange":						 {dslType: "vdsl", vid: "835", connType: "ppp"},	
		"VDSL_Sfr(835)":					 {dslType: "vdsl", vid: "835", connType: "ppp"},
		"VDSL_Sfr(836)":					 {dslType: "vdsl", vid: "836", connType: "ppp"},	
		"VDSL_Free":						 {dslType: "vdsl", vid: "836", connType: "dhcp"},
		"VDSL_Bouygues Telecom":			 {dslType: "vdsl", vid: "200", connType: "dhcp"},
		"VDSL_Numericable":					 {dslType: "vdsl", vid: "200", connType: "dhcp"},
		"VDSL_Ovh":					 		 {dslType: "vdsl", vid: "835", connType: "ppp"},
		"VDSL_Nordnet":					 	 {dslType: "vdsl", vid: "835", connType: "ppp"},
		"ADSL_Orange(PPPoE)": 				 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}, 
		"ADSL_Orange(PPPoA)": 				 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Orange(Dynamic IP)": 			 {dslType: "adsl", pvc: "8/36", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Sfr(PPPoE)": 					 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Sfr(PPPoA)": 					 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Sfr(Dynamic IP)": 			 {dslType: "adsl", pvc: "8/36", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Bouygues Telecom(PPPoE)":  	 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Bouygues Telecom(PPPoA)": 	 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Bouygues Telecom(Dynamic IP)": {dslType: "adsl", pvc: "8/36", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Numericable(PPPoE)":  		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Numericable(PPPoA)": 			 {dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Numericable(Dynamic IP)": 	 {dslType: "adsl", pvc: "8/36", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Free(PPPoE LLC)":  			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Free(PPPoE VCMUX)":  			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "VCMUX"},
		"ADSL_Free(Dynamic IP Bridged)": 	 {dslType: "adsl", pvc: "8/36", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Free(Dynamic IP Routed)": 	 {dslType: "adsl", pvc: "8/36", connType: "dhcp", encapMode: "1483 Routed VCMUX"},
		"ADSL_Ovh": 				 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}, 
		"ADSL_Nordnet": 				 	 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}	
	},
	"Germany":
	{
		"VDSL_Telekom":							{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_1&1 Internet": 					{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_Vodafone/Arcor(VID132)":			{dslType: "vdsl", vid: "132", connType: "ppp"},
		"VDSL_Vodafone/Arcor(VID7)":			{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_Vodafone/Arcor(VID8)":			{dslType: "vdsl", vid: "8", connType: "dhcp"},
		"VDSL_O2(VID11)":						{dslType: "vdsl", vid: "11", connType: "ppp"},
		"VDSL_O2(VID7)":						{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_Alice(VID11)": 					{dslType: "vdsl", vid: "11", connType: "ppp"},
		"VDSL_Alice(VID7)":						{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_Congstar": 						{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_easybell": 						{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_Encoline": 						{dslType: "vdsl", vid: "142", connType: "dhcp"},
		"VDSL_Ewetel": 							{dslType: "vdsl", vid: "2019", connType: "ppp"},
		"VDSL_GMX":								{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_M-net":							{dslType: "vdsl", vid: "40", connType: "ppp"},
		"VDSL_Osnatel":							{dslType: "vdsl", vid: "2019", connType: "ppp"},
		"VDSL_swb(VID7)":						{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_swb":								{dslType: "vdsl", vid: "0", connType: "ppp"},
		"VDSL_Versatel":						{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_wilhelm.tel":						{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_Willy.tel":						{dslType: "vdsl", vid: "2511", connType: "ppp"},
		"VDSL_KielNET DSL":						{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_Netcologne(VID10)":				{dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_NetCologne(VID7)":				{dslType: "vdsl", vid: "7", connType: "ppp"},
		"VDSL_QSC/Q-DSL home":					{dslType: "vdsl", vid: "7", connType: "ppp"},
		"ADSL_Telekom": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_1&1 Internet": 					{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Vodafone/Arcor 1/32":				{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Vodafone/Arcor 8/35":				{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_O2": 								{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Congstar": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Alice(Hansenet)": 				{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Alice(Hansenet)8/35": 			{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_GMX": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Web.de": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_AOL": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_BITel": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Callando": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_CNE": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Compuserve": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Comtel": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Dokom": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Envia TEL": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_EWETEL": 							{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Freenet": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Hansenet": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Helenet": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Infocity(PPPoE)": 				{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Infocity(Dynamic IP)":			{dslType: "adsl", pvc: "1/32", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Lycos": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_M-net": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Mediacom": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_multikabel isdn": 				{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Netfcom": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Neocom": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_net dsl": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_net cologne": 					{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_new dsl": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_nordkom": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Primacom": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Primacom/Primaspeed": 			{dslType: "adsl", pvc: "1/32", connType: "dhcp", encapMode: "LLC"},
		"ADSL_QSC/Q-DSL": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_R2 Online": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Schlund & Partner": 				{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_T link": 							{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Tiscali": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Versatel": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"}
	},
	"Greece":
	{
		"VDSL_CYTA": 			{dslType: "vdsl", vid: "835", connType: "ppp"},
		"VDSL_Hellas Online": 	{dslType: "vdsl", vid: "835", connType: "ppp"},
		"VDSL_WIND": 			{dslType: "vdsl", vid: "835", connType: "ppp"},
		"VDSL_OTE": 			{dslType: "vdsl", vid: "835", connType: "ppp"},
		"VDSL_Forthnet": 		{dslType: "vdsl", vid: "1102", connType: "ppp"},
		"ADSL_OTE": 	 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Forthnet": 	 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Hellas Online":  	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_On Telecoms": 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_CYTA": 			{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_WIND": 	 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_VODAFONE": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Hungary":
	{
		"ADSL_Matav Telecom": {dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"}
	},
	"Iceland":
	{
		"ADSL_Iceland Telecom": {dslType: "adsl", pvc: "8/48", connType: "pppoa", encapMode: "LLC"},
		"ADSL_1Islandssimi 1":  {dslType: "adsl", pvc: "8/48", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_2Islandssimi 2":  {dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "VCMUX"}
	},
	"India":
	{
		"ADSL_BSNL": 	 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_MTNL": 	 	{dslType: "adsl", pvc: "0/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Airtel": 	 	{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Reliance": 	{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Tata": 	 	{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Connect": 	{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"}
	},
	"Indonesia":
	{
		"ADSL_PT Telkom DIVER1(Sumatra)": 			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_PT Telkom DIVER2(Jakarta)Alcatel": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_PT Telkom DIVER3(Jakarta)Siemens": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_PT Telkom DIVER4(West Java)": 	 	{dslType: "adsl", pvc: "8/81", connType: "ppp", encapMode: "LLC"},
		"ADSL_PT Telkom DIVER5(Central Java)": 		{dslType: "adsl", pvc: "8/81", connType: "ppp", encapMode: "LLC"},
		"ADSL_PT Telkom DIVER6(East Java)": 	 	{dslType: "adsl", pvc: "8/81", connType: "ppp", encapMode: "LLC"},
		"ADSL_PT Telkom DIVER7(East Indonesia)": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}
	},
	"Iran":
	{
		"ADSL_Iran Telecom(Copper Lines)":  		{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_Iran Telecom(PCM Lines)": 			{dslType: "adsl", pvc: "1/32", connType: "br", encapMode: "LLC"},
		"ADSL_Iran Telecom(Optical Fibre Lines)": 	{dslType: "adsl", pvc: "8/81", connType: "br", encapMode: "LLC"},
		"ADSL_Pars Online(Tehran)":				 	{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_Pars Online(Others)": 				{dslType: "adsl", pvc: "0/59", connType: "br", encapMode: "LLC"},
		"ADSL_Shatel": 								{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_DATAK": 								{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_Asre Telecom": 						{dslType: "adsl", pvc: "8/35", connType: "br", encapMode: "LLC"},
		"ADSL_Asiatech": 							{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_FANAVA": 								{dslType: "adsl", pvc: "8/35", connType: "br", encapMode: "LLC"},
		"ADSL_Novin Net(Dadeh Gostar)": 			{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_SABA Net": 							{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_Pishgaman(Tehran)": 					{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_Pishgaman Kavir Yazd": 				{dslType: "adsl", pvc: "8/81", connType: "br", encapMode: "LLC"}
	},
	"Ireland":
	{ 
		"VDSL_Eircom": 					 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_BBnet": 					 {dslType: "vdsl", vid: "10", connType: "ppp"},
		"ADSL_Eircom": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_BT Ireland": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Vodafone Ireland": {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Digiweb": 		 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Irish Broadband":  {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Magnet": 			 {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Israel":
	{
		"VDSL_BEZEQ": 					 {dslType: "vdsl", vid: "0", connType: "ppp"},
		"ADSL_Bezeq International(014)": {dslType: "adsl", pvc: "8/48", connType: "ppp", encapMode: "LLC"},
		"ADSL_Netvision(013)": 			 {dslType: "adsl", pvc: "8/48", connType: "ppp", encapMode: "LLC"},
		"ADSL_Golden Lines(012)": 		 {dslType: "adsl", pvc: "8/48", connType: "ppp", encapMode: "LLC"},
		"ADSL_Triple C": 				 {dslType: "adsl", pvc: "8/48", connType: "ppp", encapMode: "LLC"},
		"ADSL_Xphone(018)": 			 {dslType: "adsl", pvc: "8/48", connType: "ppp", encapMode: "LLC"}
	},
	"Italy":
	{
		"ADSL_Tiscali (Italy)": 					 	{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Alice (T.I.)": 							{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Libero (Wind)": 							{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_LIBERO/WIND/INFOSTRADA": 					{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_TELE 2": 									{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_TELECOMITALIA ADSL Smart 10/Smart 15": 	{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Aria Tel": 								{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Eli Tel": 							 	{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_FASTWEB LIGHT(ADSL)": 				 	{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_TIN.IT/VIRGILIO": 					 	{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Aruba": 									{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Nextra": 									{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Telvia": 									{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_MCLink": 									{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"}
	},
	"Kazakhstan":
	{	 
		"ADSL_Megaline": 	 {dslType: "adsl", pvc: "0/40", connType: "ppp", encapMode: "LLC"}
	},
	"Luxembourg":
	{
		"ADSL_Online ANALOGUE":  	{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_LuxDSL": 				{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Online ISDN": 		{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "LLC"}
	},
	"Malaysia":
	{
		"ADSL_Streamyx(Telecom Malaysia-TMNet)PPPoE": {dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Streamyx(Telecom Malaysia-TMNet)PPPoA": {dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Maxis": 								  {dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "LLC"}
	},
	"Mexico":
	{
		"ADSL_Telmex 8/81": 	{dslType: "adsl", pvc: "8/81", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telmex 0/35": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Maxcom": 			{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Netherlands":
	{
		"VDSL_KPN": 		{dslType: "vdsl", vid: "6", connType: "ppp"},
		"VDSL_Voiceworks": 	{dslType: "vdsl", vid: "101", connType: "dhcp"},
		"VDSL_XS4ALL": 		{dslType: "vdsl", vid: "6", connType: "ppp"},
		"VDSL_Telfort": 	{dslType: "vdsl", vid: "34", connType: "ppp"},
		"ADSL_KPN": 		{dslType: "adsl", pvc: "8/48", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Online": 		{dslType: "adsl", pvc: "8/48", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Stipte": 		{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Tel2": 		{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_Telfort": 	{dslType: "adsl", pvc: "0/34", connType: "br", encapMode: "LLC"}, 
		"ADSL_Solcon": 		{dslType: "adsl", pvc: "0/36", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_XS4ALL":  	{dslType: "adsl", pvc: "8/48", connType: "pppoa", encapMode: "VCMUX"}
	},
	"New Zealand":
	{
		"VDSL_Spark/Telecom": 		{dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_KiwiLink": 			{dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_Slingshot": 			{dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_Vodafone NZ": 		{dslType: "vdsl", vid: "10", connType: "dhcp"},
		"VDSL_Snap": 				{dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_Myrepublic": 			{dslType: "vdsl", vid: "10", connType: "dhcp"},
		"VDSL_Callplus with PPPOE": {dslType: "vdsl", vid: "10", connType: "ppp"},
		"VDSL_Callplus with IPOE": 	{dslType: "vdsl", vid: "10", connType: "dhcp"},
		"ADSL_New Zealand Telcom": 	{dslType: "adsl", pvc: "0/100", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Telcom Xtra": 		{dslType: "adsl", pvc: "0/100", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_IHUG": 				{dslType: "adsl", pvc: "0/100", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_IGRIN Internet": 		{dslType: "adsl", pvc: "0/100", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Actrix": 				{dslType: "adsl", pvc: "0/100", connType: "pppoa", encapMode: "VCMUX"}
	},
	"Norway":
	{
		"ADSL_Telenor 1": {dslType: "adsl", pvc: "0/100", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telenor 2": {dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Palestinian Authority":
	{
		"ADSL_Hadara": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Mada": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Call U": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Super Link": 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Gemzo": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Zone": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Zaytona": 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Peru":
	{
		"ADSL_Telefonica": {dslType: "adsl", pvc: "8/60", connType: "ppp", encapMode: "LLC"}
	},
	"Poland":
	{
		"VDSL_ORANGE":					{dslType: "vdsl", vid: "35", connType: "ppp"},
		"VDSL_NETIA VDSL": 				{dslType: "vdsl", vid: "0", connType: "ppp"},
		"ADSL_Neostrada (ORANGE)PPPoA": {dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Neostrada (ORANGE)PPPoE": {dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_DialnetDSL": 				{dslType: "adsl", pvc: "1/32", connType: "br", encapMode: "LLC"},
		"ADSL_Net24": 					{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_GTS Energis": 			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Netia(PPPoE) ADSL": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Netia(PPPoA) ADSL": 		{dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Dialog(PPPoE)": 			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Dialog(Bridge)": 			{dslType: "adsl", pvc: "1/32", connType: "br", encapMode: "LLC"},
		"ADSL_TK Telekom TDI(Bridge)": 	{dslType: "adsl", pvc: "0/35", connType: "br", encapMode: "LLC"},
		"ADSL_TK Telekom netk@(PPPOA)": {dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Multimedia": 				{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"}
	},
	"Portugal":
	{
		"ADSL_ONI": 								{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_PT(Internet)":  						{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_PT(MEO)(Single Edge 3PLAY-IPTV)": 	{dslType: "adsl", pvc: "1/35", connType: "staip", encapMode: "LLC"},
		"ADSL_PT(MEO)(Dual Edge 3PLAY-Internet)":  	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_PT(MEO)(Dual Edge 3PLAY-IPTV)":  		{dslType: "adsl", pvc: "1/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Vodafone": 							{dslType: "adsl", pvc: "0/35", connType: "ipoa", encapMode: "LLC"},
		"ADSL_Clix":  								{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}
	},
	"Qatar":
	{
		"VDSL_Q-Tel/Ooreedo": 	{dslType: "vdsl", vid: "8", connType: "ppp"},
		"ADSL_Q-Tel/Ooreedo(PPPoA)":	{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Q-Tel/Ooreedo(PPPoE)":	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Russia":
	{
		"VDSL_Rostelecom (Domolink)":		{dslType: "vdsl", vid: "0", connType: "ppp"},
		"ADSL_MTC": 						{dslType: "adsl", pvc: "1/50", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Москва": 			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Белгород": 			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Брянск": 			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Владимир": 			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Курск": 				{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Тула": 				{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Калуга": 			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Рязань": 			{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Иваново": 			{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Тамбов": 			{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Ярославль": 			{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Воронеж":  			{dslType: "adsl", pvc: "10/40", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Кострома": 			{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Орёл": 				{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Рыбинск":			{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Липецк": 			{dslType: "adsl", pvc: "35/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Смоленск": 			{dslType: "adsl", pvc: "0/100", connType: "ppp", encapMode: "LLC"},
		"ADSL_Домолинк-Тверь": 				{dslType: "adsl", pvc: "8/81", connType: "ppp", encapMode: "LLC"},
		"ADSL_Сибирь Телеком-Новосибирск": 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Сибирь Телеком-Омск": 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Сибирь Телеком-Томск": 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Сибирь Телеком-Иркутск": 		{dslType: "adsl", pvc: "0/100", connType: "ppp", encapMode: "LLC"},
		"ADSL_Сибирь Телеком-Другие": 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}
	},
	"Saudi Arabia":
	{
		"ADSL_STC": {dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}
	},
	"Singapore":
	{
		"ADSL_Singnet(PPPoE)": 				{dslType: "adsl", pvc: "0/100", connType: "ppp", encapMode: "LLC"},
		"ADSL_Singnet(PPPoA-LLC)": 			{dslType: "adsl", pvc: "0/100", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Singnet(PPPoA-VC/MUX)": 		{dslType: "adsl", pvc: "0/100", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_SingTel Magix": 				{dslType: "adsl", pvc: "0/101", connType: "ipoa", encapMode: "LLC"},
		"ADSL_SingTel MegaPOP(Biz Users)": 	{dslType: "adsl", pvc: "8/35", connType: "ipoa", encapMode: "LLC"}
	},
	"Slovak Republic":
	{
		"VDSL_T-Com":						{dslType: "vdsl", vid: "2510", connType: "ppp"},
		"VDSL_Orange":						{dslType: "vdsl", vid: "2510", connType: "ppp"},
		"VDSL_AMIS":						{dslType: "vdsl", vid: "0", connType: "ppp"},
		"ADSL_T-Com(Slovakia)": 			{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_AMIS": 						{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"}
	},
	"Spain":
	{
		"VDSL_Telefonica": 					{dslType: "vdsl", vid: "6", connType: "ppp"},
		"VDSL_Vodafone - Link Direct": 		{dslType: "vdsl", vid: "100", connType: "dhcp"},
		"VDSL_Vodafone - Link Indirect": 	{dslType: "vdsl", vid: "100", connType: "ppp"},
		"VDSL_Jazztel": 					{dslType: "vdsl", vid: "1074", connType: "ppp"},
		"ADSL_Arrakis": 					{dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Auna": 						{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Comunitel": 					{dslType: "adsl", pvc: "0/33", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Eresmas": 					{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_EuskalTel": 					{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Jazztel ADSL": 				{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Jazztel ADSL2+/Desagregado": 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_OpenforYou": 					{dslType: "adsl", pvc: "8/32", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Orange(IPoA/IP FIJA)": 		{dslType: "adsl", pvc: "8/32", connType: "ipoa", encapMode: "LLC"},
		"ADSL_Orange 20Mb(Direct link)": 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Orange(Indirect link)": 		{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Telefonica-Spain": 			{dslType: "adsl", pvc: "8/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Telefonica": 					{dslType: "adsl", pvc: "8/32", connType: "ipoa", encapMode: "LLC"},
		"ADSL_Tele 2": 						{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Tele 2 - Comunitel": 			{dslType: "adsl", pvc: "0/33", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Terra": 						{dslType: "adsl", pvc: "8/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Terra(IPoA/IP FIJA)": 		{dslType: "adsl", pvc: "8/32", connType: "ipoa", encapMode: "LLC"},
		"ADSL_YA.COM ADSL": 				{dslType: "adsl", pvc: "8/32", connType: "ppp", encapMode: "VCMUX"},
		"ADSL_YA.COM ADSL(Static IP)": 		{dslType: "adsl", pvc: "8/32", connType: "ipoa", encapMode: "LLC"},
		"ADSL_YA.COM ADSL(PPPoA)": 			{dslType: "adsl", pvc: "8/32", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Vodafone ADSL(Direct link)": 	{dslType: "adsl", pvc: "0/44", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Vodafone ADSL(Indirect link)": {dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Ono": 						{dslType: "adsl", pvc: "8/35", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Pepephone ADSL": 				{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"}
	},
	"Sweden":
	{
		"ADSL_Bredbandsbolaget (PPPoE)": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}, 
		"ADSL_Bredbandsbolaget (Dynamic IP)": 	{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"}, 
		"ADSL_Bredbandsbolaget (Static IP)": 	{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Bredband2": 						{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Glocalnet (PPPoE)": 				{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Glocalnet (Dynamic IP)": 			{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Glocalnet (Static IP)": 			{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Net at Once": 					{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_No Com": 							{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Ownit (Dynamic IP)": 				{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Ownit (Static IP)": 				{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Skanova": 						{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Spray": 							{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Tele2 (Dynamic IP)": 				{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Tele2 (Static IP)": 				{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Telia (Dynamic IP)": 				{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Telia (Static IP)": 				{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Universal Telecom (Dynamic IP)": 	{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Universal Telecom (Static IP)": 	{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Teletek": 						{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_Teleman": 						{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_llTele (Dynamic IP)": 			{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_AllTele (Static IP)": 			{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"},
		"ADSL_AllTele (PPPoE)": 				{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Bjäre Kraft (Dynamic IP)": 		{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Bjäre Kraft (Static IP)": 		{dslType: "adsl", pvc: "8/35", connType: "staip", encapMode: "LLC"}
	},
	"Switzerland":
	{
		"VDSL_Swisscom":						{dslType: "vdsl", vid: "10", connType: "ppp"},
		"ADSL_Swisscom": 						{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Green naked": 					{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Cablecom": 						{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Sunrise": 						{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Monzoon": 						{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_M-Budget": 						{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_DFI": 							{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Syrian Arab Republic":
	{
		"ADSL_STE": {dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"}
	},
	"Taiwan":
	{
		"ADSL_Hinet": {dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"}
	},
	"Thailand":
	{
		"ADSL_TOT": 			 	{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_CAT": 			 	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_3BB": 			 	{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Buddy": 				{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_CS loxinfo(True)": 	{dslType: "adsl", pvc: "0/100", connType: "ppp", encapMode: "LLC"},
		"ADSL_CS loxinfo(TOT)":  	{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_CS loxinfo": 			{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}
	},
	"Tunisia":
	{
		"ADSL_Global Net": {dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "LLC"}
	},
	"Turkey":
	{
		"VDSL_All ISPs": 					{dslType: "vdsl", vid: "35", connType: "ppp"},
		"VDSL_TTNET": 						{dslType: "vdsl", vid: "55", connType: "dhcp"},
		"ADSL_TTNET": 						{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_D-Smart Net(Smile ADSL)": 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Turkcell Superonline": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_TurkNet": 					{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Vodafone Net(Biri ADSL)": 	{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Doping": 						{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"}
	},
	"Ukraine":
	{
		"ADSL_Matrix": 				{dslType: "adsl", pvc: "0/33", connType: "br", encapMode: "LLC"},
		"ADSL_Inter-Telecom": 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Укртелеком - ОГО!": 	{dslType: "adsl", pvc: "1/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_Vega": 				{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_Cyfra": 				{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Укртелеком - ОГО! Динамический IP": 		{dslType: "adsl", pvc: "1/40", connType: "dhcp", encapMode: "LLC"}
	},
	"United Kingdom":
	{
		"VDSL_BT": 					{dslType: "vdsl", vid: "101", connType: "ppp"},
		"VDSL_Plusnet": 			{dslType: "vdsl", vid: "101", connType: "ppp"},
		"VDSL_IDnet": 				{dslType: "vdsl", vid: "101", connType: "ppp"},
		"VDSL_TalkTalk": 			{dslType: "vdsl", vid: "101", connType: "dhcp"},
		"VDSL_EE": 					{dslType: "vdsl", vid: "101", connType: "ppp"},
		"VDSL_Vispa": 				{dslType: "vdsl", vid: "101", connType: "ppp"},
		"VDSL_Zen": 				{dslType: "vdsl", vid: "101", connType: "ppp"},
		"VDSL_AAISP": 				{dslType: "vdsl", vid: "101", connType: "ppp"},
		"VDSL_Claranet": 			{dslType: "vdsl", vid: "101", connType: "ppp"},
		"ADSL_BT": 					 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_AOL": 				 {dslType: "adsl", pvc: "0/38", connType: "ppp", encapMode: "LLC"},
		"ADSL_Karoo": 				 {dslType: "adsl", pvc: "1/50", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Bulldog": 			 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Demon": 				 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Force 9": 			 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_New Breed Telekom": 	 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Nildram": 			 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_O2(BE Broadband)": 	 {dslType: "adsl", pvc: "0/101", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Pipex": 				 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_PlusNet": 			 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Sky Broadband(BSkyB)": {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Supanet": 			 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Talk Talk": 			 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Tesco": 				 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Tiscali/Lineone": 	 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Virgin": 				 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Wanadoo/Orange": 		 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Chess Telecom": 		 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Post Office": 		 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Zen": 				 {dslType: "adsl", pvc: "0/38", connType: "pppoa", encapMode: "VCMUX"}
	},
	"United States":
	{
		"ADSL_All Tel(0/35 PPPoE LLC)": 							{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_All Tel(0/35 Dynamic IP LLC)": 						{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_AT&T[SBC/Bellsouth](0/35 PPPoE LLC)": 				{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_AT&T[SBC/Bellsouth](0/35 Dynamic IP LLC)": 			{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_AT&T[SBC/Bellsouth](8/35 PPPoE LLC)": 				{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_AT&T[SBC/Bellsouth](8/35 Dynamic IP LLC)": 			{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Augest.net(8/35 Dynamic IP LLC)": 					{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Augest.net(0/35 Dynamic IP LLC)": 					{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Bellsouth": 											{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Casstle.net": 										{dslType: "adsl", pvc: "0/96", connType: "dhcp", encapMode: "LLC"},
		"ADSL_CenturyLink(8/35 PPPoE LLC)": 						{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_CenturyLink(8/35 Dynamic IP LLC)": 					{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_CentryTel(8/35 PPPoE LLC)": 							{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_CentryTel(8/35 Dynamic IP LLC)": 						{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Coqui.net": 											{dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Covad": 												{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Earthlink(0/35 PPPoE LLC)": 							{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Earthlink(8/35 PPPoE LLC)": 							{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Earthlink(8/35 PPPoE VCMUX)": 						{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "VCMUX"},
		"ADSL_Eastex": 												{dslType: "adsl", pvc: "0/100", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Embarq": 												{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_4DV.net": 											{dslType: "adsl", pvc: "0/32", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Grande Communications": 								{dslType: "adsl", pvc: "1/34", connType: "ppp", encapMode: "LLC"},
		"ADSL_GWI": 												{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Hotwire": 											{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_InReach(8/35 Dynamic IP LLC)": 						{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_InReach(0/35 Dynamic IP LLC)": 						{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Internet Junction": 									{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_CenturyLink (Former Qwest, 0/32 PPPOA VCMUX)": 		{dslType: "adsl", pvc: "0/32", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_CenturyLink (Former Qwest, 0/32 PPPOA LLC)": 			{dslType: "adsl", pvc: "0/32", connType: "pppoa", encapMode: "LLC"},
		"ADSL_CenturyLink (Former Qwest, 0/32 PPPOE LLC)": 			{dslType: "adsl", pvc: "0/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_CenturyLink (Former Qwest, 0/32 Dynamic IP LLC)": 	{dslType: "adsl", pvc: "0/32", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Socket(8/35 Dynamic IP LLC)": 				 		{dslType: "adsl", pvc: "8/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Socket(0/35 Dynamic IP LLC)": 				 		{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Socket(0/35 PPPoE LLC)": 						 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Sonic": 										 		{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_South Western Bell": 							 		{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Sprint(0/35 PPPoA LLC)": 						 		{dslType: "adsl", pvc: "0/35", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Sprint(8/35 PPPoE LLC)": 						 		{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_SureWest Communications(0/34 Dynamic IP LLC)": 		{dslType: "adsl", pvc: "0/34", connType: "dhcp", encapMode: "LLC"},
		"ADSL_SureWest Communications(0/32 PPPoE LLC)": 	 		{dslType: "adsl", pvc: "0/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_SureWest Communications(0/32 PPPoA LLC)": 	 		{dslType: "adsl", pvc: "0/32", connType: "pppoa", encapMode: "LLC"},
		"ADSL_Toast.Net": 									 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Uniserve": 									 		{dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"},
		"ADSL_US West": 									 		{dslType: "adsl", pvc: "0/32", connType: "pppoa", encapMode: "VCMUX"},
		"ADSL_Verizon(0/35 PPPoE LLC)": 					 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Verizon(0/35 Dynamic IP LLC)": 				 		{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"},
		"ADSL_Windstream(0/35 PPPoE LLC)": 					 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_Windstream(0/35 Dynamic IP LLC)": 			 		{dslType: "adsl", pvc: "0/35", connType: "dhcp", encapMode: "LLC"}
	},
	"Venezuela":
	{
		"ADSL_CANTV": {dslType: "adsl", pvc: "0/33", connType: "dhcp", encapMode: "LLC"}
	},
	"Viet Nam":
	{
		"VDSL_FPT VDSL":			{dslType: "vdsl", vid: "0", connType: "ppp"},
		"ADSL_Viettel": 			{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_FPT ADSL": 			{dslType: "adsl", pvc: "0/33", connType: "ppp", encapMode: "LLC"},
		"ADSL_VNPT Hanoi2": 		{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_VNPT Hanoi3": 		{dslType: "adsl", pvc: "0/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_VNPT HCMC": 			{dslType: "adsl", pvc: "8/35", connType: "ppp", encapMode: "LLC"},
		"ADSL_VNPT Thai Binh":  	{dslType: "adsl", pvc: "0/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_VNPT Ninh Binh":  	{dslType: "adsl", pvc: "0/32", connType: "ppp", encapMode: "LLC"},
		"ADSL_VNPT Quang Tri":  	{dslType: "adsl", pvc: "0/35", connType: "ppp", encapMode: "LLC"}
	}	
}
