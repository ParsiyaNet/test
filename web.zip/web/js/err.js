﻿// 1, 1001
var CMM_ERROR				= 1;
var CMM_RSL_CONFLICT_KEY	= 1001;

// 4500-4599 updata Firmware/Config
var CMM_CFG_FILE_TOO_LONG = 4500;
var CMM_CFG_FILE_FORMAT_ERR = 4501;
var CMM_UPDATE_FILE_LEN_ERR = 4502;
var CMM_UPDATE_FILE_VER_ERR = 4503;
var CMM_GET_SIGN_ERR = 4504;
var CMM_RESTORE_DEFAULT_CFG_ERR = 4505;
var CMM_UPDATE_ADDI_HW_VER_ERR = 4506;

// 4600-4620	sys user
// 4621-4640	management control
// 4641-4660	httpd config

// 4700-4799	Firewall
var CMM_FW_ILLEGAL_IP					= 4700;	/* illegal ip */
var CMM_FW_NOT_LAN_IP					= 4701;	/* expect lan IP; but get not */
var CMM_FW_LAN_IP						= 4702;	/* expert not lan ip; but get */
var CMM_FW_ILLEGAL_PORT					= 4703;	/* illegal port number */
var CMM_FW_ILLEGAL_MAC					= 4704;	/* illegal MAC */
var CMM_FW_EMPTY_INTERNAL_HOST			= 4705;	/* set interanl host without value */
var CMM_FW_EMPTY_EXTERNAL_HOST			= 4706;	/* set exteranl host without value */
var CMM_FW_EMPTY_TASK_SCHEDULE			= 4707;	/* set task schedule without value */
var CMM_FW_EMPTY_RULE					= 4708;	/* set rule without value */
var CMM_FW_ILLEGAL_RULE					= 4709;	/* illegal rule */
var CMM_FW_CONFLICT_INTERNAL_HOST		= 4710;	/* conflict internal host. */
var CMM_FW_CONFLICT_EXTERNAL_HOST		= 4711;	/* conflict external host. */
var CMM_FW_CONFLICT_TASK_SCHEDULE		= 4712;	/* conflict task schedule */
var CMM_FW_CONFLICT_RULE				= 4713;	/* conflict rule entry */
var CMM_FW_EMPTY_URL					= 4714;	/* set empty url */
var CMM_FW_REACH_MAX_URL				= 4715;	/* reach max url number */
var CMM_FW_REQ_DENY						= 4716;	/* request deny */
var CMM_FW_SET_TIMER_ERROR				= 4717;	/* set firewall timer error */
var CMM_FW_MALLOC_RULE_FAILED			= 4718;	/* get memory for rule entry failed */
var CMM_FW_SET_DEFAULT_ACTION_FAILED	= 4719;	/* set default action to HOOK failed */
var CMM_FW_SET_URL_FAILED				= 4720;	/* set url failed. */
var CMM_PC_INHOST_IS_NOT_MAC			= 4721;	/* internal host is for parent control; but 
												 * the internal host is not MAC type */
var CMM_PC_EXHOST_IS_NOT_URL			= 4722;	/* external host is for parent control; but 
												 * the external host is not url type */
var CMM_PC_MAC_IS_SAME_WITH_PARENT_MAC	= 4723;	/* child's MAC is same with parent's MAC */
var CMM_FW_NAME_INCLUDE_INVALID_CHAR	= 4724;	/* entry name include invalid character */
var CMM_FW_NAME_END_WITH_SPACE			= 4725;	/* entry name is end with space */
var CMM_FW_INVILID_URL					= 4726;	/* invalid URL */
var CMM_PC_MAC_IS_SAME_WITH_CHILD_MAC	= 4727;	/* parent's MAC is same with child's MAC */
	
// 4800-4899	QoS & TC
var CMM_TC_DOWN_BANDWIDTH				= 4800;
var CMM_TC_UP_BANDWIDTH					= 4801;
var CMM_TC_CONFLICT						= 4802;
var CMM_TC_START_IP_ERROR				= 4803;
var CMM_TC_END_IP_ERROR					= 4804;            
var CMM_TC_DOWN_TOTAL_BW				= 4805;
var CMM_TC_UP_TOTAL_BW					= 4806;
var CMM_TC_UP_TOTAL_BW_VOIP				= 4807;
var	CMM_TC_VOIP_BW_ZERO					= 4808;
var CMM_TC_MAX_ERROR					= 4849;
var CMM_QOS_EMPTY_QUEUE         		= 4850;
var CMM_QOS_WRR_TOTALBW_ZERO    		= 4851;
var CMM_QOS_MAX_PRIO            		= 4852;
var CMM_QOS_SAME_QUEUE_NAME     		= 4853;
var CMM_QOS_SAME_QUEUE_PRIO     		= 4854;
var CMM_QOS_MAX_QUEUE_WEIGHT    		= 4855;
var CMM_QOS_SCH_NOT_SUPPORTED   		= 4856;
var CMM_QOS_SAME_APP_NAME       		= 4857;
var CMM_QOS_NONEXIST_APP_INTF   		= 4858;
var CMM_QOS_NOT_WAN_APP_INTF    		= 4859;
var CMM_QOS_NONEXIST_APP_QUEUE  		= 4860;
var CMM_QOS_NONEXIST_CLS_INTF   		= 4861;
var CMM_QOS_NONEXIST_CLS_QUEUE  		= 4862;
var CMM_QOS_EMPTY_CLS_INGRESS_INTF 		= 4863;
var CMM_QOS_SAME_CLS_NAME       		= 4864;
var CMM_QOS_SAME_CLS_CRITERION  		= 4865;
var CMM_QOS_CLS_SRC_IP_NON_LAN  		= 4866;
var CMM_QOS_CLS_DEST_IP_LAN     		= 4867;
var CMM_QOS_CLS_SRC_IP_LAN      		= 4868;
var CMM_QOS_CLS_DEST_IP_NON_LAN 		= 4869;
var CMM_QOS_INTF_INVALID        		= 4870;

// 4900-4999	Forward
// DMZ (4900-4929)
var CMM_DMZ_IP_NOT_IN_LAN_SUBNET	= 4903; 
// VS (4930-4969)
var CMM_VS_INVALID_LOCAL_IP_PARAM	= 4930;
var CMM_VS_PROTO_TYPE_ERR			= 4931;
var CMM_VS_ADD_NEW_INTERNAL_ERR 	= 4932;
var CMM_VS_DEL_OLD_INTERNAL_ERR 	= 4933;
var CMM_VS_RECORD_ALREADY_FULL		= 4934;
var CMM_VS_RECORD_ALREADY_EXIST 	= 4935;
var CMM_VS_PORT_OUT_RANGE			= 4936;
var CMM_VS_IP_NOT_IN_LAN_SUBNET 	= 4937;
var CMM_VS_CONFLICT_REMOTE_WEB_PORT = 4938;
// PT (4970-4999)
var CMM_PT_RECORD_ALREADY_FULL 		= 4970;
var CMM_PT_OPEN_PROTO_TYPE_ERR		= 4971;
var CMM_PT_TRIG_PROTO_TYPE_ERR		= 4972;
var CMM_PT_TRIG_PORT_CONFLICT		= 4973;
var CMM_PT_TRIG_PORT_OUT_RANGE		= 4974;
var CMM_PT_OPEN_PORT_OUT_RANGE		= 4975;
var CMM_PT_ADD_NEW_INTERNAL_ERR		= 4976;
var CMM_PT_DEL_OLD_INTERNAL_ERR		= 4977;

// 5000-5099	DHCP server
var CMM_LAN_IP_ERR 													= 5000;
var CMM_LAN_MASK_ERR 												= 5001;
var CMM_LAN_IP_MASK_DISMATCH 										= 5002;
var CMM_LAN_IP_IN_THE_SAME_SUBNET_WITH_WAN 							= 5003;
var CMM_LAN_IP_IN_THE_SAME_SUBNET_WITH_OTHER_LAN 					= 5004;
var CMM_LAN_UNEXPECT_EXISTING_LAN_IP_AND_MASK						= 5005;
	
var CMM_DHCPS_SRV_MIN_ADDR_ERR 										= 5010;
var CMM_DHCPS_SRV_MAX_ADDR_ERR 										= 5011;
var CMM_DHCPS_SRV_GATEWAY_ADDR_ERR									= 5012;
var CMM_DHCPS_SRV_DNS1_ADDR_ERR 									= 5013;
var CMM_DHCPS_SRV_DNS2_ADDR_ERR 									= 5014;
var CMM_DHCPS_SRV_RELAY_SRV_ADDR_ERR 								= 5015;
var CMM_DHCPS_SRV_RELAY_SRV_ADDR_EMPTY 								= 5016;
var CMM_DHCPS_SRV_MIN_ADDR_NOT_IN_THE_SAME_SUBNET 					= 5017;
var CMM_DHCPS_SRV_MAX_ADDR_NOT_IN_THE_SAME_SUBNET 					= 5018;
var CMM_DHCPS_SRV_GATEWAY_ADDR_NOT_IN_THE_SAME_SUBNET 				= 5019;
	
var CMM_DHCPS_FIX_MAP_MAC_ADDR_ERR 									= 5020;
var CMM_DHCPS_FIX_MAP_IP_ADDR_ERR 									= 5021;
var CMM_DHCPS_FIX_MAP_IP_NOT_IN_THE_SAME_SUBNET 					= 5022;
var CMM_DHCPS_FIX_MAP_MAC_CONFLICT 									= 5023;
var CMM_DHCPS_FIX_MAP_IP_CONFLICT 									= 5024;

var CMM_DHCPS_CONDITIONAL_POOL_DEVICE_NAME_EMPTY 					= 5030;
var CMM_DHCPS_CONDITIONAL_POOL_VID_EMPTY 							= 5031;
var CMM_DHCPS_CONDITIONAL_POOL_MIN_ADDR_ERR 						= 5032;
var CMM_DHCPS_CONDITIONAL_POOL_MAX_ADDR_ERR 						= 5033;
var CMM_DHCPS_CONDITIONAL_POOL_IPRouters_ADDR_ERR 					= 5034;
var CMM_DHCPS_CONDITIONAL_POOL_DNS1_ADDR_ERR 						= 5035;
var CMM_DHCPS_CONDITIONAL_POOL_DNS2_ADDR_ERR 						= 5036;
var CMM_DHCPS_CONDITIONAL_POOL_MIN_ADDR_NOT_IN_THE_SAME_SUBNET 		= 5038;
var CMM_DHCPS_CONDITIONAL_POOL_MAX_ADDR_NOT_IN_THE_SAME_SUBNET 		= 5039;
var CMM_DHCPS_CONDITIONAL_POOL_GATEWAY_ADDR_NOT_IN_THE_SAME_SUBNET 	= 5040;
var CMM_DHCPS_CONDITIONAL_POOL_DEVICE_NAME_CONPLICT 				= 5041;
var CMM_DHCPS_CONDITIONAL_POOL_VID_CONPLICT 						= 5042;
var CMM_DHCPS_CONDITIONAL_POOL_POOLS_CONPLICT						= 5043;
var CMM_DHCPS_CONDITIONAL_POOL_OPTION_CODE_INVALID 					= 5044;
var CMM_DHCPS_CONDITIONAL_POOL_OPTION_VALUE_EMTPY 					= 5045;
var CMM_DHCPS_CONDITIONAL_POOL_VID_ERR								= 5046;

// 5100-5199	router
var	CMM_DEFAULT_ROUTE_NAME_ERR 			= 5100;
var	CMM_STATIC_ROUTE_DEST_IP_ERR		= 5101;
var	CMM_STATIC_ROUTE_DEST_SUB_ERR 		= 5102;
var	CMM_STATIC_ROUTE_GATEWAY_ERR 		= 5103;
var	CMM_STATIC_ROUTE_SUB_DISMATCH_IP 	= 5104;
var	CMM_STATIC_ROUTE_DEST_CONFLICT_LAN 	= 5105;
var	CMM_STATIC_ROUTE_DEST_CONFLICT_WAN 	= 5106;
var	CMM_STATIC_ROUTE_ENTRY_CONFLICT 	= 5107;
var	CMM_STATIC_ROUTE_NOT_SAME_NET 		= 5108;
var	CMM_STATIC_ROUTE_NAME_ERR			= 5109;

// 5200-5299	DNS & DDNS
var	CMM_DNS_DEFAULT_NAME_ERR 	= 5200;
var	CMM_DNS_SET_ERR 			= 5201;
var	CMM_DDNS_PH_START_ERROR 	= 5210;
var CMM_DDNS_PH_CFG_MSG_ERROR = 5211;
var	CMM_DDNS_PH_RT_MSG_ERROR 	= 5212;
var CMM_DDNS_PH_STATE_GET_ERROR = 5213;
var CMM_DDNS_PH_USR_ERROR = 5214;
var CMM_DDNS_PH_PWD_ERROR = 5215;
var CMM_DDNS_PH_NO_RUN = 5216;
var CMM_DYNDNS_USERNAME_ERROR = 5217;
var CMM_DYNDNS_PASSWORD_ERROR = 5218;
var CMM_DYNDNS_USERDOMAIN_ERROR = 5219;
var CMM_DYNDNS_SERVER_ERROR = 5220;
var CMM_NOIPDNS_USERNAME_ERROR = 5221;
var CMM_NOIPDNS_PASSWORD_ERROR = 5222;
var CMM_NOIPDNS_USERDOMAIN_ERROR = 5223;
var CMM_NOIPDNS_SERVER_ERROR = 5224;

// 5300-5349	SNTP
var	CMM_SNTP_SET_ERR 		= 5300;
var	CMM_SNTP_YEAR_ERR 		= 5303;
var	CMM_SNTP_MONTH_ERR 		= 5304;
var	CMM_SNTP_DAY_ERR 		= 5305;
var	CMM_SNTP_HOUR_ERR 		= 5306;
var	CMM_SNTP_MONUTES_ERR 	= 5307;
var	CMM_SNTP_SECONDS_ERR 	= 5308;

var	CMM_DST_START_INVALID = 5310;	
var	CMM_DST_END_INVALID = 5311;		
var	CMM_DST_CFG_INVALID = 5312;		

// 5350-5399	CLI

// 5400-5499	IP&ARP
var CMM_ARP_BIND_ENTRY_OVERFLOW = 5400;
var CMM_ARP_BIND_ENTRY_CONFLICT_WHEN_EDIT = 5401;
var CMM_ARP_BIND_ENTRY_CONFLICT_WHEN_IMPORT = 5402;
var CMM_ARP_BIND_ENTRY_IP_ADDR_ERR = 5403;
var CMM_ARP_BIND_ENTRY_MAC_ADDR_ERR = 5404;
var CMM_ARP_BIND_ENTRY_STATE_ERR = 5405;
var CMM_ARP_BIND_ENTRY_IP_NOT_IN_LAN_SUBNET = 5406;
var CMM_ARP_BIND_ADD_SYS_ENTRY_FAILED = 5407;
var CMM_ARP_BIND_DEL_SYS_ENTRY_FAILED = 5408;
var CMM_ARP_BIND_SET_SYS_ENTRY_FAILED = 5409;
var CMM_ARP_BIND_PARAM_FORMAT_ERR = 5410;

// 5500-5519	AutoPVC

// 5520-5549	IPTV
var	CMM_IPTV_INVALIED_VCI 			= 5520;
var	CMM_IPTV_INVALIED_VPI 			= 5521;
var	CMM_IPTV_INVALIED_LANPORT		= 5522;
var	CMM_IPTV_BR_NOTIN_GROUP			= 5523;
var	CMM_IPTV_LAN_NOTIN_GROUP		= 5524;	
var CMM_IPTV_LANPORT_ALREADY_USED	= 5525;

// 5550-5569	ETH WAN
var	CMM_ETHWAN_INTF_NOTIN_DFTGROUP	= 5550;
var	CMM_ETHWAN_INTF_NAME_IS_NULL	= 5551;
var	CMM_ETHWAN_VIR_PORTS_IS_NOT_EN	= 5552;
var	CMM_ETHWAN_LANPORT_ALREADY_USED = 5554;
/* Added by YCY, 24May12 */
var CMM_ETHWAN_INTF_NOT_EXIST		= 5555;
/* end ycy */

var CMM_WAN_DSL_SCR_INVAD                       = 5570;
var CMM_WAN_DSL_PCR_INVAD                       = 5571;
var CMM_WAN_DSL_SCR_LARGER_THAN_PCR             = 5572;
var CMM_WAN_DSL_MBS_INVAD						= 5573;
var CMM_WAN_DSL_CFG_HAS_NO_INTF					= 5574;
var CMM_WAN_DSL_ERR_LINKTYPE					= 5575;

/* Added by YCY, 24May12 */
/* WAN common error code(5650-5699). Divide frome bridge's error code. YCY. 07May12*/
var	CMM_WAN_INVALID_AC_TYPE						= 5650;
var	CMM_WAN_LINK_CFG_IFNAME_NULL				= 5651;
var	CMM_WAN_NO_LINK_CFG_OBJ						= 5652;
var	CMM_WAN_UNKNOWN_CONN_TYPE					= 5653;
var	CMM_WAN_CAL_FAKE_MAC_FAILED					= 5654;
/* end ycy */

// 5700-5799 Static IP & Dynamic IP
var CMM_WAN_IP_BOOL_FORMAT_ERROR				= 5700;
var CMM_WAN_IP_PARAM_NOT_VALID_VALUE			= 5701;
var CMM_WAN_IP_INVALID_IP_ADDR_FORMAT			= 5702;
var CMM_WAN_IP_IFNAME_ERROR					    = 5703;
var CMM_WAN_IP_MAC_ADDR_ERROR                   = 5704;
var CMM_WAN_IP_CLONE_MAC_ADDR_ERROR             = 5705;
var CMM_WAN_IP_MAC_OVERRIDE_ERROR				= 5706;
var CMM_WAN_IP_MAC_CLONE_ERROR					= 5707;
var CMM_WAN_IP_IP_IN_THE_SAME_SUBNET_WITH_LAN   = 5708;
var CMM_WAN_IP_DNS_ADDR_ERROR                   = 5709;
var CMM_WAN_IP_IP_ADDR_ERROR                    = 5710;
var CMM_WAN_IP_GATEWAY_ADDR_ERROR               = 5711;
var	CMM_STATIC_IP_INTF_ERR						= 5712;
var	CMM_IPOA_NONE_SINGLE_PVC_MULTI_CONN			= 5713;

var CMM_WAN_IPOA_INTF_ERROR						= 5717;


//5900-5999
var	CMM_PPP_BOOL_FORMAT_ERROR					= 5900;
var	CMM_PPP_PARAM_NOT_VALID_VALUE				= 5901;
var	CMM_INVALID_PPP_ADDR_FORMAT					= 5902;
var	CMM_PPP_INTF_ERROR							= 5903;
var	CMM_PPP_MAC_OVERRIDE_ERROR					= 5904;
var	CMM_PPP_MAC_CLONE_ERROR						= 5905;
var CMM_WAN_EXCEED_LIMITED_NUM					= 5906;
var	CMM_WAN_NO_DSL_INTF_ERROR					= 5907;
var	CMM_PPPOA_NONE_SINGLE_PVC_MULTI_CONN		= 5908;
var	CMM_WAN_PPP_IP_IN_THE_SAME_SUBNET_WITH_LAN 	= 5909;
var	CMM_WAN_INVALID_DNS							= 5910;
/* Added by YCY, 24May12 */
var	CMM_WAN_NO_PPPOA_INTF					= 5911;
var	CMM_WAN_PPPOA_ASSIGN_PVC_FAIL			= 5912;
var	CMM_WAN_PPPOA_NO_DSL_CFG				= 5913;
var	CMM_WAN_GENERATE_MAC_FAILED				= 5914;
var	CMM_WAN_UNKOWN_PPP_CONN_TYPE			= 5915;
var	CMM_PPP_NO_ETH_CFG_INTF					= 5916;
/* end ycy */

//6100-6199 USB
var	CMM_USB_MORE_ALIVE_DEV						= 6100;
var	CMM_USB_MORE_ALIVE_LOG						= 6101;
var	CMM_USB_VOLUME_UMOUNT_FAIL					= 6102;
var CMM_USB_NOBODY_ERROR						= 6103;
var CMM_USB_ILLEGAL_FOLDER_PATH					= 6104;
var CMM_USB_3G_UNLOCK_PIN_CODE_FAIL				= 6110;
var CMM_USB_3G_FILE_TOO_LONG					= 6111;
var CMM_USB_3G_FILE_FORMAT_ERR					= 6112;
var CMM_USB_3G_TOO_MANY_ENTRIES					= 6113;
var CMM_USB_3G_UPLOAD_PARSE_FAILED				= 6114;
var CMM_USB_3G_ENTRY_ALREADY_EXIST				= 6115;
var CMM_USB_3G_MODEM_ENTRIES_FULL				= 6116;
	
// 6200-6299 IPv6
var CMM_ROUTE6_ADDR_VALID				= 6200;
var CMM_ROUTE6_DEFAULT_ROUTE_NAME_ERR	= 6201;
var CMM_ROUTE6_PREFIX_LEN_VALID			= 6210;
var CMM_ROUTE6_ENTRY_DUPLICATE			= 6211;
var CMM_ROUTE6_DEST_CONFLICT_LAN 		= 6212;
var CMM_ROUTE6_GW_PFX_NOT_SAME_WITH_WAN = 6213;
	
var CMM_WAN6_INTF_NOT_EXIST				= 6220;

var CMM_TUNNEL6_6RD_PREFIX_INVALID		= 6230;
	
// 7500-7999 WLAN
var CMM_WLAN_PARAM_CONFLICTE 				= 7500;	
var CMM_WLAN_INVALID_PARAM_VALUE			= 7501;	
var CMM_WLAN_SSID_CONFLICTE					= 7503;	
var CMM_WLAN_MACFILTER_ADDR_CONFLICT		= 7504;	
var CMM_WLAN_SSID_CONFLICTE_WITH_GUESTNET	= 7505;	
var CMM_WLAN_READ_DEFAULT_PIN_FAILED		= 7508;	

//7600 IPSEC
var	CMM_TUNNEL_NAME_ALREADY_EXITS           = 7800;
var	CMM_TUNNEL_IP_ALREADY_EXITS             = 7801;
var	CMM_TUNNEL_LOCAL_IP_SHOULD_IN_LAN       = 7802;
var	CMM_TUNNEL_REMOTE_IP_CONFLICT_LAN       = 7803;
var CMM_TUNNEL_ALREADY_10_TUNNEL_EXITS		= 7804;
var CMM_TUNNEL_REMOTE_GW_EMPTY				= 7805;
var CMM_TUNNEL_LOCAL_IP_INVALID				= 7806;
var CMM_TUNNEL_LOCAL_SUBMASK_INVALID		= 7807;
var CMM_TUNNEL_REMOTE_IP_INVALID			= 7808;
var CMM_TUNNEL_REMOTE_SUBMASK_INVALID		= 7809;
var CMM_TUNNEL_PRESHARE_KEY_NOT_BE_EMPTY	= 7810;
var CMM_TUNNEL_PH1_NOT_POSITIVE				= 7811;
var CMM_TUNNEL_PH2_NOT_POSITIVE				= 7812;
var CMM_TUNNEL_INVALID_ENC_KEY				= 7813;
var CMM_TUNNEL_ENC_KEY_LENGTH_ERR			= 7814;
var CMM_TUNNEL_ENC_KEY_HEX					= 7815;
var CMM_TUNNEL_INVALID_AUTH_KEY				= 7816;
var CMM_TUNNEL_SPI_INVALID					= 7817;
var CMM_TUNNEL_MY_IDENTIFIER_NOT_EMPTY		= 7818;
var CMM_TUNNEL_PEER_IDENTIFIER_NOT_EMPTY	= 7819;
var CMM_TUNNEL_IDENTIFIER_FQDN				= 7820;
var CMM_TUNNEL_MODE_AGGRESSIVE				= 7821;

// 9000 DM
var CMM_METHOD_NOT_SUPPORTED				= 9000;
var CMM_REQUEST_DENIED						= 9001;
var CMM_INTERNAL_ERROR						= 9002;
var CMM_INVALID_ARGUMENTS					= 9003;
var CMM_RESOURCE_EXCEEDED					= 9004;
var CMM_INVALID_PARAM_NAME					= 9005;
var CMM_INVALID_PARAM_TYPE					= 9006;
var CMM_INVALID_PARAM_VALUE 				= 9007;
var CMM_INVALID_CONFIG_FILE					= 9802;
var CMM_OBJECT_NOT_FOUND					= 9804;
var CMM_INSTANCE_NOT_FOUND					= 9805;
var CMM_OBJECT_BUF_EXCEEDED					= 9808;
var CMM_REACH_MAX_INSTANCE_NUM				= 9812;

// 71000-71999 errno from httpd
var ERR_HTTP_BASE = 71000;

var HTTP_ERR_FORMAT = 71011;
var ERR_HTTP_ERR_GET = 71012;
var ERR_HTTP_ERR_SET = 71013;
var ERR_HTTP_ERR_CGI_INVALID_FORMAT = 71014;
var ERR_HTTP_ERR_CGI_INVALID_OP = 71015;
var ERR_HTTP_ERR_CGI_INVALID_CGI = 71016;
var ERR_HTTP_ERR_CGI_INVALID_ANSI = 71017;
var ERR_HTTP_ERR_IO = 71111;
var ERR_HTTP_ERR_SOFT_UP = 71211;
var ERR_HTTP_ERR_CONF_UP = 71221;
var ERR_HTTP_ERR_USER_TYPE = 71231;
var ERR_HTTP_ERR_USER_CMM_ARG = 71232;
var ERR_HTTP_ERR_USER_PWD_NOT_CORRECT = 71233;
var ERR_HTTP_ERR_USER_WEB_ARG = 71234;
var ERR_HTTP_ERR_TOOL_GET_IPMAC = 71241;

//errno from WEB
//80000 - 80999 WEB basic error
var ERR_UNKOWN = 80000;

var ERR_EXIT = 80001;
var ERR_NONE_FILE = 80002;

var ERR_GET = 80011;
var ERR_SET = 80012;

var ERR_NUM_INVAD = 80101;
var ERR_NUM_OUTRANGE = 80102;

var ERR_STR_NOT_ASCII = 80201;

var ERR_IP_FORMAT = 80301;
var ERR_IP_BROADCAST = 80302;
var ERR_IP_SUBNETA_NET_0 = 80303;
var ERR_IP_LOOPBACK = 80304;
var ERR_IP_SUBNETC_HOST_255 = 80305;
var ERR_IP_MULTICAST = 80306;
var ERR_IP_PRESERVED = 80307;

var ERR_MASK_INVAD = 80308;

var ERR_IPMASK_SUBNET_INVAD = 80309;
var ERR_IPMASK_HOST_INVAD = 80310;
var ERR_IPGW_NOT_SAME_SUBNET = 80311;

var ERR_MAC_FORMAT = 80401;
var ERR_MAC_ZERO = 80402;
var ERR_MAC_BROADCAST = 80403;
var ERR_MAC_MULTICAST = 80404;

// 84400-84599 CWMP
var ERR_CWMP_URL_INVAD = 84400;
var ERR_CWMP_PATH_INVAD = 84401;
var ERR_CWMP_PORT_INVAD = 84402;

// 84500-84599 updata Firmware/Config
var ERR_CONF_FILE_NONE = 84500;
var ERR_FIRM_FILE_NONE = 84501;

// 84600-84619	sys user
var ERR_USER_OLD_PWD_EMPTY = 84600;
var ERR_USER_OLD_PWD_ASCII = 84601;
var ERR_USER_NAME_EMPTY = 84602;
var ERR_USER_NAME_ASCII = 84603;
var ERR_USER_PWD_EMPTY = 84604;
var ERR_USER_PWD_ASCII = 84605;
var ERR_USER_NAME_PWD_CONFLICT = 84606;

// 84620-84639	management control
var ERR_APP_LOCAL_HOST = 84620;
var ERR_APP_REMOTE_HOST = 84621;

// 84640-84659	httpd config
var ERR_HTTP_LOCAL_PORT = 84640;
var ERR_HTTPS_LOCAL_PORT = 84641;
var ERR_HTTP_HTTPS_LOCAL_CONFILICT = 84642;
var ERR_HTTP_REMOTE_PORT = 84643;
var ERR_HTTP_REMOTE_HTTPS_LOCAL_CONFILICT = 84644;
var ERR_HTTPS_REMOTE_PORT = 84645;
var ERR_HTTP_LOCAL_HTTPS_REMOTE_CONFILICT = 84646;
var ERR_HTTP_HTTPS_REMOTE_CONFILICT = 84647;
var ERR_HTTP_LOCAL_PORT_CONFLICT = 84648;
var ERR_HTTP_REMOTE_PORT_CONFLICT = 84649;

// 84661-84680	time
var ERR_TIME_YEAR_INVAD = 84661;
var ERR_TIME_MONTH_INVAD = 84662;
var ERR_TIME_DAY_INVAD = 84663;
var ERR_TIME_HOUR_INVAD = 84664;
var ERR_TIME_MINUTE_INVAD = 84665;
var ERR_TIME_SECOND_INVAD = 84666;
var ERR_TIME_NTP_SERVER = 84667;

// 84700-84799	FierWall
var ERR_FW_ENTRYNAME_INVAD = 84700;
var ERR_FW_URL_INVAD = 84701;
var ERR_FW_RULE_INVAD = 84702;
var ERR_FW_TIME_INVAD = 84703;
var ERR_FW_URL_NULL = 84704;

// 84800-84899	QoS & TC
var ERR_TC_IP_PORT_INVAD		= 84800;
var ERR_TC_NUM_INVAD			= 84801;
var ERR_PORT_NUM_INVAD			= 84802;
var ERR_PORT_ORDER_INVAD		= 84803;
var ERR_EMPTY_START_PORT		= 84804;
var ERR_TC_IP_ORDER_INVAD		= 84805;
var ERR_TC_BW_ORDER_INVAD		= 84806;
var ERR_TC_EMPTY_START_IP		= 84807;
var ERR_TC_BW_NULL				= 84808;

var ERR_QOS_TOTALBW_INVAD 		= 84850;
var ERR_QOS_TOTALBW_INVAD_SP 	= 84851;
var ERR_QOS_QUEUE_DIR 			= 84852;
var ERR_QOS_QUEUE_NAME 			= 84853;
var ERR_QOS_QUEUE_NAME_LENGTH 	= 84854;
var ERR_QOS_QUEUE_WEIGHT_NUM 	= 84855;
var ERR_QOS_QUEUE_SCH 			= 84856;
var ERR_QOS_CLS_NAME 			= 84857;
var ERR_QOS_CLS_NAME_LENGTH 	= 84858;
var ERR_QOS_CLS_INTF_INVAD 		= 84859;
var ERR_MAC_MASK_INVAD 			= 84860;
var ERR_QOS_EMPTY_QUEUE 		= 84861;
var ERR_QOS_APP_NAME 			= 84862;

// 84900-84999	Forward
var ERR_VS_PORT_INVAD = 84930;
var ERR_FW_ADD_FAILED = 84931;
var ERR_FTP_DATA_PORT_CONFLICT = 84932;
var ERR_VS_INTER_PORT_INVAD = 84933;

// 85000-85099 LAN & DHCPS
var ERR_LAN_IP_INVAD = 85000;
var ERR_LAN_MASK_INVAD = 85001;
var ERR_LAN_IPMASK_INVAD = 85002;

var ERR_DHCP_START_IP_INVAD = 85010;
var ERR_DHCP_END_IP_INVAD = 85011;
var ERR_DHCP_LEASE_INVAD = 85012;
var ERR_DHCP_GATEWAY_INVAD = 85013;
var ERR_DOMAIN_INVAD = 85014;
var ERR_DHCP_DNS1_INVAD = 85015;
var ERR_DHCP_DNS2_INVAD = 85016;
var ERR_DHCP_RMT_SRV_EMPTY = 85017;
var ERR_DHCP_RMT_SRV_INVAD = 85018;
var ERR_LAN_SEC_IP_INVAD = 85019;
var ERR_DHCP_POOL_INVAD = 85020;
var ERR_DHCP_START_IP_INVAD_1 = 85021;
var ERR_DHCP_END_IP_INVAD_1 = 85022;

var ERR_DHCP_COND_POOL_DEV_NAME_EMPTY = 85040;
var ERR_DHCP_COND_POOL_VID_EMPTY = 85041;
var ERR_DHCP_COND_POOL_START_IP_INVAD = 85042;
var ERR_DHCP_COND_POOL_END_IP_INVAD = 85043;
var ERR_DHCP_COND_POOL_GW_INVAD = 85044;
var ERR_DHCP_COND_POOL_OPT_VAL_EMPTY = 85045;
var ERR_DHCP_COND_DNS1_INVAD = 85046;
var ERR_DHCP_COND_DNS2_INVAD = 85047;
var ERR_GATEWAY_INVAD = 85048;
var ERR_DHCP_COND_POOL_VID_INVAD = 85049;
var ERR_DHCP_COND_POOL_DEV_NAME_INVALID = 85050;

// 85100-85199 route

// 85200-85299 DNS&DDNS
var ERR_DDNS_USERNAME_EMPTY = 85200;
var ERR_DDNS_PWD_EMPTY = 85201;
var ERR_DDNS_DOMAIN_INVAD = 85202;

// 85300-85349 SNTP

// 85350-85399 CLI

// 85400-85499 ARP
var ERR_ARP_CONFLICT = 85401;
var ERR_SEL_INVAD = 85402;

// 85500-85519	AutoPVC
var ERR_AUTOPVC_VPI_INVAD = 85501;
var ERR_AUTOPVC_VCI_INVAD = 85502;
var ERR_AUTOPVC_EXSIST_INVAD = 85503;

// 85520-85549	IPTV

// 85550-85569	ETH WAN

// 85590-85599 DSL
var ERR_DSL_MODULATION_MODE_NULL =85591; 

// 85600-85699	Bridge
//wan
var ERR_WAN_VPI_VCI_INVAD 	= 85601;
var ERR_WAN_PCR_INVAD 		= 85602;
var ERR_WAN_SCR_INVAD 		= 85603;
var ERR_WAN_MBS_INVAD 		= 85604;
var ERR_WAN_CONNECTIONTYPE_NULL  = 85605;
var ERR_WAN_CONNECTIONTYPE_INVAD = 85606;
var ERR_WAN_MTU_INVAD = 85607;
var ERR_WAN_DNSADDR_INVAD = 85608;
var ERR_WAN_SECDNS_INVAD = 85609;
var ERR_WAN_ECHOTIME_INVAD = 85610;
var ERR_WAN_USERNAME_INVAD = 85611;
var ERR_WAN_PWD_INVAD = 85612;
var ERR_WAN_PPPOE_MTU_INVAD = 85613;
var ERR_WAN_DEFGATEWAY_INVAD = 85614;
var ERR_AUTOPVC_INVAD = 85615;
var ERR_AUTOPVC_IP_FORMAT = 85616;
var ERR_GROUP_INVAD = 85617;
var ERR_INTERFACE_INVAD = 85618;
var ERR_GROUP_NAME_INVAD = 85619;
var ERR_PWD_INVAD = 85620;
var ERR_USERNAME_INVAD = 85621;
var ERR_WAN_SCR_EMPTY = 85622;
var ERR_WAN_PCR_EMPTY = 85623;
var ERR_WAN_SCR_LARGER_THAN_PCR = 85624;
var ERR_WAN_INTER_GROUPNAME_INVALID = 85625;
var ERR_WAN_MBS_EMPTY = 85626;
var ERR_WAN_VLANID_INVAD = 85627;

// 85700-85799	Static IP/IPoA
var ERR_STAIP_IP_INVAD = 85700;
var ERR_STAIP_MASK_INVAD = 85701;
var ERR_STAIP_GW_INVAD = 85702;
var ERR_STAIP_IP_MASK_CONFLICT = 85703;
var ERR_STAIP_GW_MASK_CONFLICT = 85704;
var ERR_STAIP_IP_GW_CONFLICT = 85705;
var ERR_STAIP_DNS1_INVAD = 85706;
var ERR_STAIP_DNS2_INVAD = 85707;
var ERR_IPOA_PVC_INVAD = 85708;

// 85800-85899	Dynamic IP
var ERR_WAN_HOST_NAME_INVALID = 85800;
var ERR_WAN_DNS_INVAD = 85801;

// 85900-85999	PPPoE/PPPoA	
var ERR_IDLETIME_INVAD = 85900;
var ERR_PPPOA_PVC_INVAD = 85901;

// 86000-86099 SNMP
var ERR_SNMP_RCOMMUNITY_EMPTY	= 86000;
var ERR_SNMP_SCOMMUNITY_EMPTY	= 86001;
var ERR_SNMP_TRAP_IP_INVAD		= 86002;

//86100-86199 USB
var ERR_USB_SHARE_NAME_EMPTY					= 86111;
var ERR_USB_SHARE_NAME_NOT_ASCII				= 86112;
var ERR_USB_INVALID_CHAR_IN_FOLDER_NAME			= 86113;
var ERR_USB_DIR_NAME_EMPTY						= 86114;
var ERR_USB_DIR_NAME_NOT_ASCII					= 86115;
var ERR_USB_DIR_EXIST							= 86116;
var ERR_USB_SHARE_NAME_EXIST					= 86117;
var ERR_USB_DIR_NOT_EXIST						= 86118;
var ERR_USB_INVALID_CHAR_IN_USER_NAME			= 86119;
var ERR_USB_CONFLICT_USER_NAME					= 86120;
var ERR_USB_FTP_PORT_EMPTY						= 86121;
var ERR_USB_FTP_PORT_NOT_NUM					= 86122;
var ERR_USB_FTP_PORT_RANGE						= 86123;
var ERR_USB_FTP_PORT_CONFLICT					= 86124;
var ERR_USB_DLNA_SERVER_NAME_EMPTY              = 86125;
var ERR_USB_DLNA_SERVER_NAME_NOT_ASCII          = 86126;
var ERR_USB_DLNA_INVALID_SERVER_NAME            = 86127;
//86180-86199 USB 3G
var ERR_USB_3G_FILE_NONE						= 86180;

// 86200-86299	IPv6
var ERR_IP6_WAN_CONN_NONE		 		= 86200;

var ERR_LAN6_PREFIX_EMPTY 		 		= 86201;
var ERR_LAN6_PREFIX_INVALID		 		= 86202;
var ERR_LAN6_PREFIX_LEN_EMPTY 	 		= 86203;
var ERR_LAN6_PREFIX_LEN_INVALID   		= 86204;
var ERR_LAN6_DHCP6S_START_ID_EMPTY 		= 86205;
var ERR_LAN6_DHCP6S_END_ID_EMPTY 		= 86206;
var ERR_LAN6_LEASE_TIME_EMPTY 			= 86207;
var ERR_LAN6_DHCP6S_START_ID_INVALID	= 86208;
var ERR_LAN6_DHCP6S_END_ID_INVALID 		= 86209;
var ERR_LAN6_LEASE_TIME_INVALID   		= 86210;
var ERR_LAN6_DHCP6S_ADDR_CONFLICT 		= 86211;

var ERR_WAN6_IP_STACK_NONE				= 86220;
var ERR_WAN6_ADDR_INVAD					= 86221;
var ERR_WAN6_PFXLEN_INVAD				= 86222;
var ERR_WAN6_DNS_INVAD					= 86223;

var ERR_ROUTE6_DST_ADDR_VALID 			= 86240;
var ERR_ROUTE6_PREFIX_LEN_VALID 		= 86241;
var ERR_ROUTE6_GW_ADDR_VALID 			= 86242;
var ERR_ROUTE6_GW_VALID 				= 86243;

var ERR_TUNNEL6_DSLITE_REMOTE_INVALID	= 86250;
var ERR_TUNNEL6_DSLITE_WAN_CONN_ERR		= 86251;
var ERR_TUNNEL6_6RD_PREFIX_LEN_INVALID	= 86252;
var ERR_TUNNEL6_6RD_PREFIX_INVALID		= 86253;
var ERR_TUNNEL6_6RD_BR_INVALID			= 86254;
var ERR_TUNNEL6_6RD_IP_MASK_LEN_INVALID	= 86255;
var ERR_TUNNEL6_6RD_NOT_SUPPORT_AUTO	= 86256;
var ERR_TUNNEL6_6RD_WAN_CONN_ERR		= 86257;
var ERR_TUNNEL6_6TO4_WAN_CONN_ERR		= 86258;

var ERR_FW6_ADDR_INVAD					= 86260;
var ERR_FW6_PFXLEN_INVAD				= 86261;

// 87500-87999  Wireless
var ERR_WLAN_SSID_IS_EMPTY=87500;
var ERR_WLAN_SSID_LEN_OUTRANGE=87501;
var ERR_WLAN_WDS_SSID_IS_EMPTY=87502;
var ERR_WLAN_WDS_SSID_LEN_OUTRANGE=87503;
var ERR_WLAN_WDS_BSSID_IS_EMPTY=87504;
var ERR_WLAN_WDS_BSSID_INVALID=87505;
var ERR_WLAN_WDS_ASCII_KEY_INVALID=87506;
var ERR_WLAN_WDS_ASCII_KEY_OUTRANGE=87507;
var ERR_WLAN_WDS_HEX_KEY_INVALID=87508;
var ERR_WLAN_WDS_HEX_KEY_OUTRANGE=87509;
var ERR_WLAN_WDS_PSK_OUTRANGE=87510;
var ERR_WLAN_WDS_AUTO_CHANNEL=87511;
var ERR_WLAN_WDS_CHANNEL=87512;

var ERR_WLAN_BAND_NOT_SUPPORT_5G=87520;

var ERR_WLAN_BEACONINTERVAL_INVAD=87550;
var ERR_WLAN_RTSINTERVAL_INVAD=87551;
var ERR_WLAN_FRAGTH_INVAD=87552;
var ERR_WLAN_DTIMTH_INVAD=87553;
var ERR_WLAN_BEACONINTERVAL_OUTRANGE=87554;
var ERR_WLAN_RTSINTERVAL_OUTRANGE=87555;
var ERR_WLAN_FRAGTH_OUTRANGE=87556;
var ERR_WLAN_DTIMTH_OUTRANGE=87557;


var ERR_WLAN_PIN_EMPTY=87600;
var ERR_WLAN_PIN_LEGNTH_INVALID=87601;
var ERR_WLAN_PIN_INVALID=87602;
var ERR_WLAN_PIN_CHECKSUM_FAIL=87603;

var ERR_WLAN_11N_WEP_CONFLICT=87650;
var ERR_WLAN_11N_TKIP_CONFLICT=87651;
var ERR_WLAN_QSS_WPA_CONFLICT=87652;
var ERR_WLAN_QSS_TKIP_CONFLICT=87653;
var ERR_WLAN_QSS_WEP_CONFLICT=87654;
var ERR_WLAN_MSSID_WEP_CONFLICT=87655; 

var ERR_WLAN_WEP_NO_KEY=87700;
var ERR_WLAN_WEP_KEY_LENGTH_INVALID=87701;
var ERR_WLAN_WEP_KEY_HEX_INVALID=87702;
var ERR_WLAN_WEP_KEY_ASCII_INVALID=87703;
var ERR_WLAN_WPA_PSK_EMPTY=87704;
var ERR_WLAN_WPA_PSK_LENGTH_INVALID=87705;
var ERR_WLAN_WPA_PSK_HEX_INVALID=87706;
var ERR_WLAN_WPA_PSK_ASCII_INVALID=87707;
var ERR_WLAN_WPA_INTERVAL_INVALID=87708;
var ERR_WLAN_WPA_PORT_INVALID=887809;
var ERR_WLAN_WPA_PWD_EMPTY=887810;
var ERR_WLAN_WPA_PWD_INVALID=887811;

var ERR_WLAN_MAC_LIST_EMPTY=87750;
var ERR_WLAN_MAC_INVALID=87751;
var ERR_WLAN_MAC_CONFLICT=87752;
var ERR_WLAN_MAC_FILTER_INVALID=87753;
var ERR_WLAN_MAC_FILTER_DESCRIP_INVALID=87754;
var ERR_WLAN_5G_REGION_CHANGED=87755;
var ERR_WLAN_MODE_INVALID=87756;

//89000-89100 3G error
var ERR_PIN_CODE_EMPTY=89000;
var ERR_PIN_ASCII=89001;
var ERR_PIN_CODE_CONFLICT=89002;
var ERR_3G_INVLIAD_DIALNUM=89003;

//90000-90600 HTTP protocol error
var ERR_INTERNAL = 90000;
var ERR_NOT_FOUND = 90404;
var ERR_NOT_ACCEPTED = 90500;

//102000-? IE error
var ERR_NETWORK = 102000;

//95000-95500 vlan config error
var ERR_WAN_VLAN_ID_CONFLICT = 95000;
var ERR_WAN_VLAN_ID_INVALID = 95001;

/********************************************************************************************/
window.e_str = {};

// error strings

// 1, 1001
e_str[CMM_ERROR]				= "Internal Error!";
e_str[CMM_RSL_CONFLICT_KEY]		= "Keyword already exists! Please input another one.";

// 4500-4599 updata Firmware/Config
e_str[CMM_CFG_FILE_TOO_LONG] = "Invalid file size! Please check your file and try again.";
e_str[CMM_CFG_FILE_FORMAT_ERR] = "You put a wrong file.";
e_str[CMM_UPDATE_FILE_LEN_ERR] = "Invalid file size! Please check your file and try again.";
e_str[CMM_UPDATE_FILE_VER_ERR] = "The uploaded file was not accepted by the device.";
e_str[CMM_GET_SIGN_ERR] = "Error! Please try again.";
e_str[CMM_RESTORE_DEFAULT_CFG_ERR] = "Failed to restore default settings.";
e_str[CMM_UPDATE_ADDI_HW_VER_ERR] = "The uploaded file does not match the device's current hardware version.";

// 4600-4619	sys user
// 4620-4639	management control
// 4640-4659	httpd config

// 4700-4799	firewall & parent control
e_str[CMM_FW_ILLEGAL_IP] = "Invalid IP address!";
e_str[CMM_FW_NOT_LAN_IP] = "The LAN Host IP is not in the same subnet with LAN IP. Please input another one.";
e_str[CMM_FW_LAN_IP] = "The WAN Host IP and current LAN IP are in the same subnet. Please input another one.";
e_str[CMM_FW_ILLEGAL_PORT] = "Invalid port number! Please input another one(1-65535).";
e_str[CMM_FW_ILLEGAL_MAC] = "Invalid MAC address! The valid format is '00-00-00-00-00-00'.";
e_str[CMM_FW_EMPTY_INTERNAL_HOST] = "Please at least configure IP address, Port or MAC Address for the LAN Host.";
e_str[CMM_FW_EMPTY_EXTERNAL_HOST] = "Please at least configure IP Address, Port or MAC Address for the WAN Host.";
e_str[CMM_FW_EMPTY_TASK_SCHEDULE] = "Please configure time for the new schedule.";
e_str[CMM_FW_EMPTY_RULE] = "Please at least configure LAN Host or WAN Host for the Filtering Rule.";
e_str[CMM_FW_ILLEGAL_RULE] = "Invalid filtering rule. Please input another one.";
e_str[CMM_FW_CONFLICT_INTERNAL_HOST] = "The added LAN Host conflicts with the existing LAN Hosts.";
e_str[CMM_FW_CONFLICT_EXTERNAL_HOST] = "The added WAN Host conflicts with the existing WAN Hosts.";
e_str[CMM_FW_CONFLICT_TASK_SCHEDULE] = "The added schedule conflicts with the existing schedule.";
e_str[CMM_FW_CONFLICT_RULE] = "The added filtering rule conflicts with the existing rules.";
e_str[CMM_FW_EMPTY_URL] = "Please input at least a URL of a website!";
e_str[CMM_FW_REACH_MAX_URL] = "URL number has reached the upper limit!";
e_str[CMM_FW_REQ_DENY] = "The entry is in use, delete is not allowed!";
e_str[CMM_FW_MALLOC_RULE_FAILED] = "Internal error occurred in rule setting.";
e_str[CMM_FW_SET_DEFAULT_ACTION_FAILED] = "Failed to configure the default filtering rule.";
e_str[CMM_FW_SET_URL_FAILED] = "Failed to configure URL!";
e_str[CMM_PC_MAC_IS_SAME_WITH_PARENT_MAC] = "MAC Address of Child's PC should differ from that of Parental PC. Please input another one. ";
e_str[CMM_FW_NAME_INCLUDE_INVALID_CHAR] = "The input value should not contain: \\/\":*?<>|&. Please input another one.";
e_str[CMM_FW_NAME_END_WITH_SPACE] = "The input value should not end with whitespace characters. Please input another one.";
e_str[CMM_FW_INVILID_URL] = "The input URL contains illegal characters. Please input another one.";
e_str[CMM_PC_MAC_IS_SAME_WITH_CHILD_MAC] = "MAC Address of Parental PC should differ from that of Child's PC. Please input another one.";

// 4800-4899	QoS & TC
e_str[CMM_TC_DOWN_BANDWIDTH] = "System can't satisfy the requested min downstream rate. Please input again.";
e_str[CMM_TC_UP_BANDWIDTH] = "System can't satisfy the requested min upstream rate. Please input again.";
e_str[CMM_TC_CONFLICT] = "The added rule conflicts with the existing rules.";
e_str[CMM_TC_START_IP_ERROR] = "The Start IP Address is the same as LAN IP or not in the same subnet with LAN IP address. Please input another one.";
e_str[CMM_TC_END_IP_ERROR] = "The End IP Address is the same as LAN IP or not in the same subnet with LAN IP address. Please input another one.";
e_str[CMM_TC_DOWN_TOTAL_BW] = "The Total Downstream Bandwidth should not be less than the summation of IPTV Downstream Bandwidth Guarantee and all the min downstream rate of enabled rules.";
e_str[CMM_TC_UP_TOTAL_BW] = "The Total Upstream Bandwidth should not be less than the summation of IPTV Upstream Bandwidth Guarantee and all the min upstream rate of enabled rules.";
e_str[CMM_TC_MAX_ERROR] = "Bandwidth control rules list is full! Please delete one existing rule before adding a new one.";

e_str[CMM_QOS_EMPTY_QUEUE] = "The business or flow classification must be bound to one queue!";
e_str[CMM_QOS_WRR_TOTALBW_ZERO] = "The weight of the added WRR queue must be greater than 0!";
e_str[CMM_QOS_MAX_PRIO] = "The precedence of the added SP queue must not be greater than 8!";
e_str[CMM_QOS_SAME_QUEUE_NAME] = "The queue name of the queues with the same QoS direction must be different!";
e_str[CMM_QOS_SAME_QUEUE_PRIO] = "The precedence of the added SP queue must not be same with the existing SP queue!";
e_str[CMM_QOS_MAX_QUEUE_WEIGHT] = "The summation of all WRR queues with the same QoS direction must not be greater than 100!";
e_str[CMM_QOS_SCH_NOT_SUPPORTED] = "System can't support the requested scheduler algorithm!";
e_str[CMM_QOS_SAME_APP_NAME] = "The business name of the added business classification must not be same with the existing business classification!";
e_str[CMM_QOS_NONEXIST_APP_INTF] = "The QoS interface to which the business classification is bound does not exist!";
e_str[CMM_QOS_NOT_WAN_APP_INTF] = "Business classification must be only used for upstream QoS!";
e_str[CMM_QOS_NONEXIST_APP_QUEUE] = "The QoS queue to which the business classification is bound does not exist!";
e_str[CMM_QOS_NONEXIST_CLS_INTF] = "The QoS interface to which the flow classification is bound does not exist!";
e_str[CMM_QOS_NONEXIST_CLS_QUEUE] = "The QoS queue to which the flow classification is bound does not exist!";
e_str[CMM_QOS_EMPTY_CLS_INGRESS_INTF] = "Invalid ingress interface of the flow classification!";
e_str[CMM_QOS_SAME_CLS_NAME] = "The class name of the added flow classification must not be same with the existing flow classification!";
e_str[CMM_QOS_SAME_CLS_CRITERION] = "The criteria of the added classification must not be same with the criteria of existing classifications!";
e_str[CMM_QOS_CLS_SRC_IP_NON_LAN] = "The source IP address of flow classification for upstream QoS must be IP address of LAN side!"; 
e_str[CMM_QOS_CLS_DEST_IP_LAN] = "The destination of flow classification for upstream QoS must not be IP address of LAN side!"; 
e_str[CMM_QOS_CLS_SRC_IP_LAN] = "The source IP address of flow classification for downstream QoS must not be IP address of LAN side!"; 
e_str[CMM_QOS_CLS_DEST_IP_NON_LAN] = "The destination IP address of flow classification for downstream QoS must be IP address of LAN side!"; 
e_str[CMM_QOS_INTF_INVALID] = "Invalid QoS direction!"; 

// 4900-4999	Forward
e_str[CMM_DMZ_IP_NOT_IN_LAN_SUBNET] = "The IP address is not in the same subnet with LAN IP address. Please input another one.";
e_str[CMM_VS_RECORD_ALREADY_FULL] = "Virtual Servers entries list is full!";
e_str[CMM_VS_RECORD_ALREADY_EXIST] = "The entry already exists or its port is occupied by another one. ";
e_str[CMM_VS_PORT_OUT_RANGE] = "Invalid port number! Please input another one(1-65535).";
e_str[CMM_VS_IP_NOT_IN_LAN_SUBNET] = "The IP address is not in the same subnet with LAN IP address. Please input another one.";
e_str[CMM_VS_CONFLICT_REMOTE_WEB_PORT] = "";
e_str[CMM_PT_RECORD_ALREADY_FULL] = "Port Triggering entries list is full!";
e_str[CMM_PT_TRIG_PORT_CONFLICT] = "Trigger Port conflict!";
e_str[CMM_PT_TRIG_PORT_OUT_RANGE] = "Trigger Port must be in range(1-65535). Please input another one.";
e_str[CMM_PT_OPEN_PORT_OUT_RANGE] = "Incoming Port must be in range(1-65535). Please input another one.";

// 5000-5099	DHCP server
e_str[CMM_LAN_IP_ERR] 													= "Invalid LAN IP address! Please input another one.";
e_str[CMM_LAN_MASK_ERR] 												= "Invalid Subnet Mask! Please input another one.";
e_str[CMM_LAN_IP_MASK_DISMATCH] 										= "LAN IP does not match the Subnet Mask, or it is reserved IP Address.";
e_str[CMM_LAN_IP_IN_THE_SAME_SUBNET_WITH_WAN] 							= "The LAN IP should not be in the same subnet with WAN IP. Please input another one.";
e_str[CMM_LAN_IP_IN_THE_SAME_SUBNET_WITH_OTHER_LAN] 					= "The LAN IP should not be in the same subnet with LAN IP of other groups. Please input another one.";
e_str[CMM_LAN_UNEXPECT_EXISTING_LAN_IP_AND_MASK]						= "Failed to get default LAN IP for the new group. Please alter LAN IP and Subnet Mask of other groups.";

e_str[CMM_DHCPS_SRV_MIN_ADDR_ERR] 										= "Invalid Start IP Address. Please input another one.";
e_str[CMM_DHCPS_SRV_MAX_ADDR_ERR] 										= "Invalid End IP Address. Please input another one.";
e_str[CMM_DHCPS_SRV_GATEWAY_ADDR_ERR] 									= "Invalid Subnet Mask. Please input another one.";
e_str[CMM_DHCPS_SRV_DNS1_ADDR_ERR] 										= "Invalid Primary DNS! Please input another one.";
e_str[CMM_DHCPS_SRV_DNS2_ADDR_ERR] 										= "Invalid Secondary DNS! Please input another one.";
e_str[CMM_DHCPS_SRV_RELAY_SRV_ADDR_ERR] 								= "Invalid Remote Server's IP Address! Please input another one.";
e_str[CMM_DHCPS_SRV_RELAY_SRV_ADDR_EMPTY] 								= "Please input Remote Server's IP Address.";
e_str[CMM_DHCPS_SRV_MIN_ADDR_NOT_IN_THE_SAME_SUBNET] 					= "Start IP Address is not in the same subnet with LAN IP or it is reserved IP Address. Please input another one.";
e_str[CMM_DHCPS_SRV_MAX_ADDR_NOT_IN_THE_SAME_SUBNET] 					= "End IP Address is not in the same subnet with LAN IP or it is reserved IP Address. Please input another one.";
e_str[CMM_DHCPS_SRV_GATEWAY_ADDR_NOT_IN_THE_SAME_SUBNET] 				= "Default Gateway is not in the same subnet with LAN IP or it is reserved IP Address. Please input another one.";

e_str[CMM_DHCPS_FIX_MAP_MAC_ADDR_ERR] 									= "Invalid IP address! Please input another one.";
e_str[CMM_DHCPS_FIX_MAP_IP_ADDR_ERR] 									= "Invalid MAC address! Please input another one.";
e_str[CMM_DHCPS_FIX_MAP_IP_NOT_IN_THE_SAME_SUBNET] 						= "IP Address is not in the same subnet with LAN IP or it is reserved IP Address. Please input another one.";
e_str[CMM_DHCPS_FIX_MAP_MAC_CONFLICT]				 					= "MAC address conflicts with the existing rules. Please input another one.";
e_str[CMM_DHCPS_FIX_MAP_IP_CONFLICT] 									= "IP address conflicts with the existing rules. Please input another one.";

e_str[CMM_DHCPS_CONDITIONAL_POOL_DEVICE_NAME_EMPTY]	 					= "Please input Client Name.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_VID_EMPTY] 							= "Please input Vendor ID.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_MIN_ADDR_ERR] 							= "Invalid Start IP Address. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_MAX_ADDR_ERR] 							= "Invalid End IP Address. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_IPRouters_ADDR_ERR] 					= "Invalid or lack of Default Gateway. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_DNS1_ADDR_ERR] 						= "Invalid or lack of Primary DNS. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_DNS2_ADDR_ERR] 						= "Invalid or lack of Secondary DNS. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_MIN_ADDR_NOT_IN_THE_SAME_SUBNET] 		= "Start IP Address is not in the same subnet with LAN IP or it is reserved IP Address. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_MAX_ADDR_NOT_IN_THE_SAME_SUBNET] 		= "End IP Address is not in the same subnet with LAN IP or it is reserved IP Address. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_GATEWAY_ADDR_NOT_IN_THE_SAME_SUBNET] 	= "Default Gateway is not in the same subnet with LAN IP or it is reserved IP Address. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_DEVICE_NAME_CONPLICT] 					= "Client Name conflicts with the existing entries. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_VID_CONPLICT] 							= "Vendor ID conflicts with the existing entries. Please input another one.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_POOLS_CONPLICT]						= "DHCP Address Pool overlaps an existing DHCP address pool. Please input another one";
e_str[CMM_DHCPS_CONDITIONAL_POOL_OPTION_CODE_INVALID] 					= "Reserved option out of range.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_OPTION_VALUE_EMTPY] 					= "Please input reserved option values.";
e_str[CMM_DHCPS_CONDITIONAL_POOL_VID_ERR]								= "Vendor ID must not contain \".";

// 5100-5199	router
e_str[CMM_DEFAULT_ROUTE_NAME_ERR] = "Invalid default gateway! Please try again.";
e_str[CMM_STATIC_ROUTE_DEST_IP_ERR] = "Invalid Destination IP Address! Please input another one.";
e_str[CMM_STATIC_ROUTE_DEST_SUB_ERR] = "Invalid Subnet Mask! Please input another one.";
e_str[CMM_STATIC_ROUTE_GATEWAY_ERR] = "Invalid Gateway! Please input another one.";
e_str[CMM_STATIC_ROUTE_SUB_DISMATCH_IP] = "Subnet Mask does not match the Destination IP Address. Please input another one.";
e_str[CMM_STATIC_ROUTE_DEST_CONFLICT_LAN] = "Destination IP Address should not in the same subnet with LAN IP. Please input another one.";
e_str[CMM_STATIC_ROUTE_DEST_CONFLICT_WAN] = "Destination IP Address should not in the same subnet with WAN IP. Please input another one.";
e_str[CMM_STATIC_ROUTE_ENTRY_CONFLICT] = "Entry already exists! Please input another one.";
e_str[CMM_STATIC_ROUTE_NOT_SAME_NET] = "Gateway must be in the same subnet with interface IP address. Please input another one.";
e_str[CMM_STATIC_ROUTE_NAME_ERR] = "Invalid Static Route! Please input another one.";

// 5200-5299	DNS & DDNS
e_str[CMM_DNS_DEFAULT_NAME_ERR] = "DNS error! Please try again.";
e_str[CMM_DNS_SET_ERR] = "Failed to configure DNS. Please try again.";
e_str[CMM_DDNS_PH_CFG_MSG_ERROR] = "Failed to configure Dynamic DNS.";
e_str[CMM_DDNS_PH_STATE_GET_ERROR] = "Failed to get DDNS information."
e_str[CMM_DDNS_PH_USR_ERROR] = "User name should be less than 64 characters.";
e_str[CMM_DDNS_PH_PWD_ERROR] = "Password should be less than 64 characters.";
e_str[CMM_DDNS_PH_NO_RUN] = "DDNS process is not running.";

// 5300-5349	SNTP
e_str[CMM_SNTP_SET_ERR] = "Static time server error! Please try again.";
e_str[CMM_SNTP_YEAR_ERR] = "Wrong format of year! Please input another one (1970-2037).";
e_str[CMM_SNTP_MONTH_ERR] = "Wrong format of month! Please input another one (01-12).";
e_str[CMM_SNTP_DAY_ERR] = "Wrong format of day! Please input another one (01-31).";
e_str[CMM_SNTP_HOUR_ERR] = "Wrong format of hour! Please input another one (00-23).";
e_str[CMM_SNTP_MONUTES_ERR] = "Wrong format of minute! Please input another one (00-60).";
e_str[CMM_SNTP_SECONDS_ERR] = "Wrong format of second! Please input another one (00-60).";


e_str[CMM_DST_START_INVALID] = "Invalid start date!",
e_str[CMM_DST_END_INVALID] = "Invalid end date!",	
e_str[CMM_DST_CFG_INVALID] = "Invalid dst config! Start date should be earlier than end date!",	
// 5350-5399	CLI

// 5400-5499	IP&ARP
e_str[CMM_ARP_BIND_ENTRY_OVERFLOW] = "The binding entries number has reached the max!";
e_str[CMM_ARP_BIND_ENTRY_CONFLICT_WHEN_EDIT] = "The ARP binding entry conflicts with the existing one!";
e_str[CMM_ARP_BIND_ENTRY_CONFLICT_WHEN_IMPORT] = "The loaded ARP entry conflicts with the existing one!";
e_str[CMM_ARP_BIND_ENTRY_IP_ADDR_ERR] = "Wrong format of IP address!";
e_str[CMM_ARP_BIND_ENTRY_MAC_ADDR_ERR] = "Wrong format of MAC address!";
e_str[CMM_ARP_BIND_ENTRY_STATE_ERR] = "Wrong status!";
e_str[CMM_ARP_BIND_ENTRY_IP_NOT_IN_LAN_SUBNET] = "The IP address is not in the same subnet as LAN IP address! Please input another one.";
e_str[CMM_ARP_BIND_ADD_SYS_ENTRY_FAILED] = "Failed to add system ARP!";
e_str[CMM_ARP_BIND_DEL_SYS_ENTRY_FAILED] = "Failed to delete system ARP!";
e_str[CMM_ARP_BIND_SET_SYS_ENTRY_FAILED] = "Failed to set system ARP!"; 
e_str[CMM_ARP_BIND_PARAM_FORMAT_ERR] = "Wrong format of parameter!";

// 5500-5519	AutoPVC

// 5520-5549	IPTV
e_str[CMM_IPTV_INVALIED_VCI]	= "Illegal VCI. Please try again!";
e_str[CMM_IPTV_INVALIED_VPI]	= "Illegal VPI. Please try again!";
e_str[CMM_IPTV_INVALIED_LANPORT]= "Illegal LAN port. Please try again!";
e_str[CMM_IPTV_BR_NOTIN_GROUP]	= "IPTV bridge connection is not in this group!";
e_str[CMM_IPTV_LAN_NOTIN_GROUP]	= "IPTV LAN port is not in this group!";
e_str[CMM_IPTV_LANPORT_ALREADY_USED] = "The LAN port for IPTV connection has been occupied by other functions, such as, Ethernet WAN connections. Please check it.";

// 5550-5569	ETH WAN
e_str[CMM_ETHWAN_INTF_NOTIN_DFTGROUP]	= "Ethernet WAN interface is not in the default group!";
e_str[CMM_ETHWAN_INTF_NAME_IS_NULL]		= "Ethernet WAN interface name is blank!";
e_str[CMM_ETHWAN_VIR_PORTS_IS_NOT_EN]	= "VLAN is disabled. Please enable it first.";
e_str[CMM_ETHWAN_LANPORT_ALREADY_USED]	= "The LAN port for Ethernet WAN connection has been occupied by other functions, such as, IPTV connections. Please check it.";
/* Added by ycy, 24May12 */
e_str[CMM_ETHWAN_INTF_NOT_EXIST]	= "Ethernet WAN interface doesn't exist!";
/* end ycy */

/* Added by xcl, 14Mar12 */
e_str[CMM_WAN_DSL_SCR_INVAD]						= "SCR value can not be empty.";
e_str[CMM_WAN_DSL_PCR_INVAD]						= "PCR value can not be empty.";
e_str[CMM_WAN_DSL_SCR_LARGER_THAN_PCR]				= "SCR value can not be larger than PCR value.";
e_str[CMM_WAN_DSL_MBS_INVAD]						= "MBS value can not be empty.";
e_str[CMM_WAN_DSL_CFG_HAS_NO_INTF]					= "DSL WAN interface doesn't exist!";
e_str[CMM_WAN_DSL_ERR_LINKTYPE]						= "Wrong link type for this IP connection!";
/* End added */

// 5600-5699	Bridge
/* Added by YCY, 24May12 */
/* WAN common error code(5650-5699). Divide frome bridge's error code. YCY. 07May12*/
e_str[CMM_WAN_INVALID_AC_TYPE]						= "Unsupported Link type!";
e_str[CMM_WAN_LINK_CFG_IFNAME_NULL]					= "The DSL/Ethernet link interface is NULL!";
e_str[CMM_WAN_NO_LINK_CFG_OBJ]						= "There isn't any DSL/Ethernet link configuration!";
e_str[CMM_WAN_UNKNOWN_CONN_TYPE]					= "The connection type isn't supported!";
e_str[CMM_WAN_CAL_FAKE_MAC_FAILED]					= "Generate MAC address failed. Please delete some and try again!";
/* end ycy */

// 5700-5899	Static IP & Dynamic IP
e_str[CMM_WAN_IP_BOOL_FORMAT_ERROR]					= "Illegal Bool type!";
e_str[CMM_WAN_IP_PARAM_NOT_VALID_VALUE]				= "The value is not in the specified string array!";
e_str[CMM_WAN_IP_INVALID_IP_ADDR_FORMAT]			= "Wrong format of IP address!";
e_str[CMM_WAN_IP_IFNAME_ERROR]					    = "Wrong interface name!";
e_str[CMM_WAN_IP_MAC_ADDR_ERROR]                   	= "Illegal MAC address or wrong format!";
e_str[CMM_WAN_IP_CLONE_MAC_ADDR_ERROR]            	= "Illegal MAC address or wrong format!";
e_str[CMM_WAN_IP_IP_IN_THE_SAME_SUBNET_WITH_LAN]   	= "WAN IP can not be in the same subnet as LAN IP!";
e_str[CMM_WAN_IP_DNS_ADDR_ERROR]                   	= "Wrong format of DNS Server address!";
e_str[CMM_WAN_IP_IP_ADDR_ERROR]                    	= "Illegal IP address or wrong format!";
e_str[CMM_WAN_IP_GATEWAY_ADDR_ERROR]               	= "Illegal Gateway or wrong format!";
e_str[CMM_STATIC_IP_INTF_ERR]						= ""; //This error id is not in using.
e_str[CMM_IPOA_NONE_SINGLE_PVC_MULTI_CONN]			= "IPoA don't support single-PVC-multi-connection. Please set available vpi/vci.";
e_str[CMM_WAN_IPOA_INTF_ERROR]						= "Failed to create IPoA interface!";

// 5900-5999	PPPoE/PPPoA	
e_str[CMM_PPP_BOOL_FORMAT_ERROR]					= "Illegal Bool type!";
e_str[CMM_PPP_PARAM_NOT_VALID_VALUE]				= "The value is not in the specified string array!";
e_str[CMM_INVALID_PPP_ADDR_FORMAT]					= "Wrong format of IP address!";
e_str[CMM_PPP_INTF_ERROR]							= "Wrong interface name!";
e_str[CMM_PPP_MAC_OVERRIDE_ERROR]					= "MAC Clone is not supported in PPPoA connection!";
e_str[CMM_PPP_MAC_CLONE_ERROR]						= "MAC Clone error!";
e_str[CMM_WAN_EXCEED_LIMITED_NUM]					= "WAN ports number exceeds the max!";
e_str[CMM_WAN_NO_DSL_INTF_ERROR]					= "There is no DSL interface!";
e_str[CMM_PPPOA_NONE_SINGLE_PVC_MULTI_CONN]			= "PPPoA don't support single-PVC-multi-connection. Please set available vpi/vci.";
e_str[CMM_WAN_PPP_IP_IN_THE_SAME_SUBNET_WITH_LAN]	= "The IP address obtained by PPP dial-up is in the same subnet with LAN IP.";
e_str[CMM_WAN_INVALID_DNS]							= "Invalid DNS address!";

e_str[CMM_WAN_NO_PPPOA_INTF]						= "Create PPPoA interface failed!";
e_str[CMM_WAN_PPPOA_ASSIGN_PVC_FAIL]				= "Failed to assign PVC to the PPPoA interface!";
e_str[CMM_WAN_PPPOA_NO_DSL_CFG]						= "No atm interface exists for this PPPoA connection!";
e_str[CMM_WAN_GENERATE_MAC_FAILED]					= "Generate MAC address failed. Please delete some and try again!";
e_str[CMM_WAN_UNKOWN_PPP_CONN_TYPE]					= "Unknown PPP connection type!";
e_str[CMM_PPP_NO_ETH_CFG_INTF]						= "The PPPoE connection doesn't have an ethernet interface!";

//6100-6199		USB
e_str[CMM_USB_MORE_ALIVE_DEV]						= "Up to two Devices could be activated at the same time!";
e_str[CMM_USB_MORE_ALIVE_LOG]						= "Up to eight volumes could be activated at the same time!";
e_str[CMM_USB_VOLUME_UMOUNT_FAIL]					= "The Logical Volume is in use, can not umount by now!";
e_str[CMM_USB_NOBODY_ERROR]							= "The User name should not be \"nobody\"!";
e_str[CMM_USB_ILLEGAL_FOLDER_PATH]					= "Illegal Directory, please change it.";
e_str[CMM_USB_3G_UNLOCK_PIN_CODE_FAIL]				= "Fail to unlock PIN protection, maybe you should input the right PIN Code!";
e_str[CMM_USB_3G_FILE_TOO_LONG]						= "Invalid file size! Please check your file and try again.";
e_str[CMM_USB_3G_FILE_FORMAT_ERR]					= "You put a wrong file.";
e_str[CMM_USB_3G_TOO_MANY_ENTRIES]					= "Too many entries for USB 3G uploaded commands! max is 4.";
e_str[CMM_USB_3G_UPLOAD_PARSE_FAILED]				= "Failed to parse upload file.";
e_str[CMM_USB_3G_ENTRY_ALREADY_EXIST]				= "Entry exists! Delete it first. The uploaded one and the existed one have the same model, but different commands.";
e_str[CMM_USB_3G_MODEM_ENTRIES_FULL]				= "USB 3G Modem Entries full! cannot upload any more.";

// 6200-6299 IPv6  
e_str[CMM_ROUTE6_ADDR_VALID]				= "The IPv6 site address is invalid!";
e_str[CMM_ROUTE6_DEFAULT_ROUTE_NAME_ERR]	= "Invalid IPv6 default gateway! Please try again.";
e_str[CMM_ROUTE6_PREFIX_LEN_VALID]			= "The prefix length is invalid!";
e_str[CMM_ROUTE6_ENTRY_DUPLICATE]			= "The IPv6 static route entry has existed.";
e_str[CMM_ROUTE6_DEST_CONFLICT_LAN]			= "The destination IPv6 address is the same with LAN.";
e_str[CMM_ROUTE6_GW_PFX_NOT_SAME_WITH_WAN]	= "The IPv6 gateway has not same site prefix with WAN!";

e_str[CMM_WAN6_INTF_NOT_EXIST]				= "The interface name of WAN IPv6 Connnection does not exist.";

e_str[CMM_TUNNEL6_6RD_PREFIX_INVALID]		= "The 6RD prefix is invalid! Please check the 6RD prefix and the 6RD prefix length.";

// 7500-7999
e_str[CMM_WLAN_PARAM_CONFLICTE] 			= "Wireless settings conflict! Please check the settings, e.g. WEP and TKIP encryption is not supported with 11n enabled.";	
e_str[CMM_WLAN_INVALID_PARAM_VALUE]			= "Invalid wireless settings!";	
e_str[CMM_WLAN_SSID_CONFLICTE]				= "The SSID has already existed. Please input another one.";	
e_str[CMM_WLAN_MACFILTER_ADDR_CONFLICT]		= "The filtering MAC address is the same as the existing one!";	
e_str[CMM_WLAN_READ_DEFAULT_PIN_FAILED]		= "Failed to get PIN code!";
e_str[CMM_WLAN_SSID_CONFLICTE_WITH_GUESTNET]= "Ths SSID has already used by Guest Network, Please input another one.";

//7800 IPSEC
e_str[CMM_TUNNEL_NAME_ALREADY_EXITS]           = "IPsec Tunnel Name already exist!";
e_str[CMM_TUNNEL_IP_ALREADY_EXITS]             = "IPsec Tunnel IP-Address already exist!";
e_str[CMM_TUNNEL_LOCAL_IP_SHOULD_IN_LAN]       = "IPsec Tunnel Local Address should be in the same subnet with LAN IP!";
e_str[CMM_TUNNEL_REMOTE_IP_CONFLICT_LAN]       = "IPsec Tunnel Remote Address should not be in the same subnet with LAN IP!";
e_str[CMM_TUNNEL_ALREADY_10_TUNNEL_EXITS]		= "Already 10 Ipsec Tunnels!";
e_str[CMM_TUNNEL_REMOTE_GW_EMPTY]				= "The remote gateway address can't be empty";
e_str[CMM_TUNNEL_LOCAL_IP_INVALID]				= "Local IP Address is invalid.";
e_str[CMM_TUNNEL_LOCAL_SUBMASK_INVALID]			= "Local Subnet Mask is invalid.";
e_str[CMM_TUNNEL_REMOTE_IP_INVALID] 			= "Remote IP Address is invalid.";
e_str[CMM_TUNNEL_REMOTE_SUBMASK_INVALID] 		= "Remote Subnet Mask is invalid.";
e_str[CMM_TUNNEL_PRESHARE_KEY_NOT_BE_EMPTY]		= "The Pre-Shared Key should not be empty";
e_str[CMM_TUNNEL_PH1_NOT_POSITIVE] 				= "Phase 1 Key Life Time isn\'t a positive integer, please check and correct!!";
e_str[CMM_TUNNEL_PH2_NOT_POSITIVE] 				= "Phase 2 Key Life Time isn\'t a positive integer, please check and correct!!";
e_str[CMM_TUNNEL_INVALID_ENC_KEY] 				= "Invalid Manual Encryption Key.";
e_str[CMM_TUNNEL_ENC_KEY_LENGTH_ERR] 			= "The manual encryption key is AES, then it's length must be 32, 48 or 64!!";
e_str[CMM_TUNNEL_ENC_KEY_HEX] 					= "Invalid Manual Encryption Key, digit Hex only.";
e_str[CMM_TUNNEL_INVALID_AUTH_KEY] 				= "Invalid Manual Authentication Key.";
e_str[CMM_TUNNEL_SPI_INVALID] 					= "The SPI value is invalid! Please input a valid one according to the rule!";
e_str[CMM_TUNNEL_MY_IDENTIFIER_NOT_EMPTY] 		= "My Identifier can't be empty!";
e_str[CMM_TUNNEL_PEER_IDENTIFIER_NOT_EMPTY] 	= "Peer's Identifier can't be empty!";
e_str[CMM_TUNNEL_IDENTIFIER_FQDN] 				= "The identifier is set to 'fqdn', then the mode should be set to main!";
e_str[CMM_TUNNEL_MODE_AGGRESSIVE] 				= "The 'Mode' should be set to 'Aggressive'";


// 9000 DM
e_str[CMM_METHOD_NOT_SUPPORTED]				= "The function call is not supported!";
e_str[CMM_REQUEST_DENIED]					= "The request is denied. Please check whether the value or operation is legal or not.";
e_str[CMM_INTERNAL_ERROR]					= "Internal error!";
e_str[CMM_INVALID_ARGUMENTS]				= "Illegal value!";
e_str[CMM_RESOURCE_EXCEEDED]				= "Buffer overflow or the value is too great!";
e_str[CMM_INVALID_PARAM_NAME]				= "Illegal parameter name!";
e_str[CMM_INVALID_PARAM_TYPE]				= "Illegal parameter type!";
e_str[CMM_INVALID_PARAM_VALUE]				= "Illegal value!";
e_str[CMM_INVALID_CONFIG_FILE]				= "Illegal configuration file! Please check its format and value.";
e_str[CMM_OBJECT_NOT_FOUND]					= "Corresponding object not found!";
e_str[CMM_INSTANCE_NOT_FOUND]				= "Corresponding case not found!";
e_str[CMM_OBJECT_BUF_EXCEEDED]				= "Object buffer overflow!";
e_str[CMM_REACH_MAX_INSTANCE_NUM]			= "The entries number has reached the max!";

// 71000-71999 errno from httpd
e_str[ERR_HTTP_ERR_GET] = "IO failed at obtaining.";
e_str[ERR_HTTP_ERR_SET] = "IO failed at configuring.";
e_str[ERR_HTTP_ERR_IO] = "Failed to access data.";
e_str[ERR_HTTP_ERR_SOFT_UP] = "Failed to upload upgrade file! You may upload a wrong file.";
e_str[ERR_HTTP_ERR_CONF_UP] = "Failed to upload configuration file! You may upload a wrong file.";
e_str[ERR_HTTP_ERR_USER_PWD_NOT_CORRECT] = "Incorrect old password!";
e_str[ERR_HTTP_ERR_TOOL_GET_IPMAC] = "Failed to get current PC's MAC address!";

//errno from WEB
//80000 - 81000 WEB basic error
e_str[ERR_UNKOWN] = "Error Unknown!";

e_str[ERR_GET] = "Failed to get parameters!";
e_str[ERR_SET] = "Failed to set parameters!";

e_str[ERR_NUM_INVAD] = "Illegal value!";
e_str[ERR_NUM_OUTRANGE] = "The value is not in the required range!";

e_str[ERR_STR_NOT_ASCII] = "The character string contains non-ASCII characters!";

e_str[ERR_IP_FORMAT] = "Wrong format of IP address!";
e_str[ERR_IP_BROADCAST] = "The IP address can not be broadcast address!";
e_str[ERR_IP_SUBNETA_NET_0] = "Class A network number of the IP address can not be 0!";
e_str[ERR_IP_LOOPBACK] = "The IP address can not be loopback address!";
e_str[ERR_MASK_INVAD] = "Illegal Subnet mask!";
e_str[ERR_IP_SUBNETC_HOST_255] = "Class C host number of the LAN IP address can not be 255!";
e_str[ERR_IP_MULTICAST] = "The LAN IP address can not be multicast address!";
e_str[ERR_IP_PRESERVED] = "The LAN IP address can not be reserved IP address!";
e_str[ERR_IPMASK_SUBNET_INVAD] = "The IP address does not match the subnet mask: illegal network number.";
e_str[ERR_IPMASK_HOST_INVAD] = "The IP address does not match the subnet mask: illegal host number.";
e_str[ERR_IPGW_NOT_SAME_SUBNET] = "The IP address is not in the same subnet as Gateway!";

e_str[ERR_MAC_FORMAT] = "Wrong format of MAC address!";
e_str[ERR_MAC_ZERO] = "The MAC address can not be in 00:00:00:00:00:00 format!";
e_str[ERR_MAC_BROADCAST] = "The MAC address can not be broadcast address!";
e_str[ERR_MAC_MULTICAST] = "The MAC address can not be multicast address!";

// 84400-84499 CWMP
e_str[ERR_CWMP_URL_INVAD] = "Please set available URL!";
e_str[ERR_CWMP_PORT_INVAD] = "Please set available port!";
e_str[ERR_CWMP_PATH_INVAD] = "Please set available path!";

// 84500-84599 updata Firmware/Config
e_str[ERR_CONF_FILE_NONE] = "Please select configuration file!";
e_str[ERR_FIRM_FILE_NONE] = "Please select upgrade file!";

// 84600-84619	sys user
e_str[ERR_USER_OLD_PWD_EMPTY] = "The Old Password can not be blank!";
e_str[ERR_USER_OLD_PWD_ASCII] = "The Old Password must be ASCII character!";
e_str[ERR_USER_NAME_EMPTY] = "The New Username can not be blank! ";
e_str[ERR_USER_NAME_ASCII] = "The New Username must be ASCII character!";
e_str[ERR_USER_PWD_EMPTY] = "The New Password can not be blank!";
e_str[ERR_USER_PWD_ASCII] = "The New Password must be ASCII character!";
e_str[ERR_USER_NAME_PWD_CONFLICT] = "The Confirm Password is not accordant with the New Password!";

// 84620-84639	management control
e_str[ERR_APP_LOCAL_HOST] = "Please enter valid IP address or MAC address!";
e_str[ERR_APP_REMOTE_HOST] = "Please enter valid IP address or MAC address!";

// 84640-84659	httpd config
e_str[ERR_HTTP_LOCAL_PORT] = "HTTP Local Management port number is not integer or it is not in the required range. Please input 80 or the integer between 1024 and 65535.";
e_str[ERR_HTTPS_LOCAL_PORT] = "HTTPS Local Management port number is not integer or it is not in the required range. Please input 443 or the integer between 1024 and 65535.";
e_str[ERR_HTTP_HTTPS_LOCAL_CONFILICT] = "HTTP Local Management port number is the same as HTTPS Local Management port number! Please input another one.";
e_str[ERR_HTTP_REMOTE_PORT] = "HTTP Remote Management port number is not integer or it is not in the required range. Please input 80 or the integer between 1024 and 65535.";
e_str[ERR_HTTP_REMOTE_HTTPS_LOCAL_CONFILICT] = "HTTP Remote Management port number is the same as HTTPS Local Management port number! Please input another one.";
e_str[ERR_HTTPS_REMOTE_PORT] = "HTTPS Remote Management port number is not integer or it is not in the required range. Please input 443 or the integer between 1024 and 65535.";
e_str[ERR_HTTP_LOCAL_HTTPS_REMOTE_CONFILICT] = "HTTP Local Management port number is the same as HTTPS Remote Management port number! Please input another one.";
e_str[ERR_HTTP_HTTPS_REMOTE_CONFILICT] = "HTTP Remote Management port number is the same as HTTPS Remote Management port number! Please input another one.";
e_str[ERR_HTTP_LOCAL_PORT_CONFLICT] = "HTTP Local Management port number has already used by other services! Please input another one.";
e_str[ERR_HTTP_REMOTE_PORT_CONFLICT] = "HTTP Remote Management port number has already used by other services! Please input another one.";

// 84660-84679	time
e_str[ERR_TIME_YEAR_INVAD] = "Wrong format of year. Please input another one (1970-2037).";
e_str[ERR_TIME_MONTH_INVAD] = "Wrong format of month! Please input another one (1-12).";
e_str[ERR_TIME_DAY_INVAD] = "Wrong format of day! Please input another one (1-31).";
e_str[ERR_TIME_HOUR_INVAD] = "Wrong format of hour! Please input another one (0-23).";
e_str[ERR_TIME_MINUTE_INVAD] = "Wrong format of minute! Please input another one (0-60).";
e_str[ERR_TIME_SECOND_INVAD] = "Wrong format of second! Please input another one (0-60).";
e_str[ERR_TIME_NTP_SERVER] = "Wrong format of NTP Server. Please input IP address or domain name.";

// 84700-84799		Firewall
e_str[ERR_FW_ENTRYNAME_INVAD] = "Please input correct description! Description must not contains \'\\\/\":*?<>|&\', and must not end with blank.";
e_str[ERR_FW_URL_INVAD] = "Please input correct URL!";
e_str[ERR_FW_RULE_INVAD] = "Please select at least one LAN Host entry or WAN Host entry!";
e_str[ERR_FW_TIME_INVAD] = "The end time should not be earlier than start time.";
e_str[ERR_FW_URL_NULL] = "Please add at least one URL entry!";

// 84800-84899	QoS & TC
e_str[ERR_TC_IP_PORT_INVAD] = "Both IP address and port number are blank! Please input one of them.";
e_str[ERR_TC_NUM_INVAD] ="Please input integers, exclude 0!"; 
e_str[ERR_PORT_NUM_INVAD] ="Invalid port number! Please input the integer between 1 and 65535.";
e_str[ERR_PORT_ORDER_INVAD] = "The end port number is less than the start port number! Please input another one.";
e_str[ERR_EMPTY_START_PORT] = "The start port number must not be blank when the end port number is not blank!";
e_str[ERR_TC_BW_ORDER_INVAD] ="The maximum bandwidth is less than the minimum bandwidth!";
e_str[ERR_TC_IP_ORDER_INVAD] ="The end IP address is less than the start IP address! Please input another one.";
e_str[ERR_TC_EMPTY_START_IP] = "The start IP address must not be blank when the end IP address is not blank!";
e_str[ERR_TC_BW_NULL] = "The minimum rate for upstream and downstream must not be both blank!";

e_str[ERR_QOS_TOTALBW_INVAD] = "Invalid total bandwidth for WRR or Traffic Control! Please input the integer between 1 and the maximum line rate.";
e_str[ERR_QOS_TOTALBW_INVAD_SP] = "Invalid total bandwidth for CAR! Please input nothing for no limitative total bandwidth,otherwise input the integer between 1 and the maximum line rate.";
e_str[ERR_QOS_QUEUE_DIR] = "Direction is blank! Please select one from list.";
e_str[ERR_QOS_QUEUE_NAME] = "Please input correct queue name!Queue name must not contains \'\\\/\":*?<>|&\', and must not end with blank.";
e_str[ERR_QOS_QUEUE_NAME_LENGTH] = "The length of queue name must be less than 12 characters!";
e_str[ERR_QOS_QUEUE_WEIGHT_NUM] = "Invalid weight! Please input the interger between 1 and 100.";
e_str[ERR_QOS_QUEUE_SCH] = "Invalid scheduler algorithm!";
e_str[ERR_QOS_CLS_NAME] = "Please input correct class name! Class name must not contains \'\\\/\":*?<>|&\', and must not end with blank.";
e_str[ERR_QOS_CLS_NAME_LENGTH] = "The length of class name must be less than 12 characters!";
e_str[ERR_QOS_CLS_INTF_INVAD] = "Ingress interface is blank! Please select one from list.";
e_str[ERR_MAC_MASK_INVAD] = "Invalid mac address mask!";
e_str[ERR_QOS_EMPTY_QUEUE] = "Queue is blank! Please select one from list.";
e_str[ERR_QOS_APP_NAME] = "Business name is blank! Please select one from list.";

// 84900-84999	Forward
e_str[ERR_VS_PORT_INVAD] = "Invalid port segment, right format of port segment is XX-XX or XX (XX belongs to integers).";
e_str[ERR_FW_ADD_FAILED] = "Editing the entry failed!";
e_str[ERR_FTP_DATA_PORT_CONFLICT] = "In order to avoid a conflict with the USB FTP Server, please use another port outside of the 59990-59999 range.";
e_str[ERR_VS_INTER_PORT_INVAD] = "Invalid internal port, right format of internal port is XX (XX belongs to integers) or just keep empty.";

// 85000-85099	DHCP server
// lancfg.htm
e_str[ERR_LAN_IP_INVAD] = "LAN port's IP address can not be null or illegal.";
e_str[ERR_LAN_MASK_INVAD] = "LAN port's Subnet Mask can not be null or illegal.";
e_str[ERR_LAN_IPMASK_INVAD] = "LAN port's IP address can't match Subnet Mask.";

e_str[ERR_DHCP_START_IP_INVAD] = "Please input Start IP.";
e_str[ERR_DHCP_END_IP_INVAD] = "Please input End IP.";
e_str[ERR_DHCP_LEASE_INVAD] = "Address lease is beyond required rang.";
e_str[ERR_DHCP_GATEWAY_INVAD] = "Wrong format of gateway!";
e_str[ERR_DOMAIN_INVAD] = "Wrong format of default domain!";
e_str[ERR_DHCP_DNS1_INVAD] = "Wrong format of primary DNS Server.";
e_str[ERR_DHCP_DNS2_INVAD] = "Wrong format of Secondary DNS Server.";
e_str[ERR_DHCP_RMT_SRV_EMPTY] = "When DHCP Relay is enabled. Please input remote DHCP Server IP.";
e_str[ERR_DHCP_RMT_SRV_INVAD] = "Wrong format of remote Server address.";
e_str[ERR_LAN_SEC_IP_INVAD] = "The second IP can't be same with LAN port's IP.";
e_str[ERR_DHCP_POOL_INVAD] = "Wrong configuration of DHCP address pool! DHCP address pool should be in the current subnet and host number must not be all 0 or all 1 binary.";	//__CHG__
e_str[ERR_GATEWAY_INVAD] = "Wrong gateway address! Gateway address should be in the current subnet and host number must not be all 0 or all 1 binary.";	//__CHG__
e_str[ERR_DHCP_START_IP_INVAD_1] = "Last portion of Start IP can not be 0 or 255.";
e_str[ERR_DHCP_END_IP_INVAD_1] = "Last portion of End IP can not be 0 or 255.";
//condPoolEdit.htm
e_str[ERR_DHCP_COND_POOL_DEV_NAME_INVALID] = "Invalid device name. Please input another one.";
e_str[ERR_DHCP_COND_POOL_DEV_NAME_EMPTY] = "Please input device names.";
e_str[ERR_DHCP_COND_POOL_VID_EMPTY] = "Please input Vendor ID.";
e_str[ERR_DHCP_COND_POOL_START_IP_INVAD] = "Please input legal Start IP.";
e_str[ERR_DHCP_COND_POOL_END_IP_INVAD] = "Please input legal End IP.";
e_str[ERR_DHCP_COND_POOL_GW_INVAD] = "Please input Gateway address.";
e_str[ERR_DHCP_COND_POOL_OPT_VAL_EMPTY] = "Please input the specified option value.";
e_str[ERR_DHCP_COND_DNS1_INVAD] = "Please input available DNS1.";
e_str[ERR_DHCP_COND_DNS2_INVAD] = "Wrong format of DNS2!";
e_str[ERR_DHCP_COND_POOL_VID_INVAD] = "Vendor ID must not contain \".";
// 85100-85199	router
// 85200-85299	DNS & DDNS
e_str[ERR_DDNS_USERNAME_EMPTY] = "User name can not be null.";
e_str[ERR_DDNS_PWD_EMPTY] = "Password can not be null.";
e_str[ERR_DDNS_DOMAIN_INVAD] = "Invalid domain name!";
e_str[CMM_DYNDNS_USERNAME_ERROR] = "User name can not be null.";
e_str[CMM_DYNDNS_PASSWORD_ERROR] = "Password can not be null.";
e_str[CMM_DYNDNS_USERDOMAIN_ERROR] = "Domain name can not be null or illegal.";
e_str[CMM_DYNDNS_SERVER_ERROR] = "Server can not be null or illegal";
e_str[CMM_NOIPDNS_USERNAME_ERROR] = "User name can not be null.";
e_str[CMM_NOIPDNS_PASSWORD_ERROR] = "Password can not be null.";
e_str[CMM_NOIPDNS_USERDOMAIN_ERROR] = "Domain name can not be null or illegal.";
e_str[CMM_NOIPDNS_SERVER_ERROR] = "Server can not be null or illegal";
// 85300-85349	SNTP
// 85350-85399	CLI
// 85400-85499	IP&ARP
e_str[ERR_ARP_CONFLICT] = "The loaded entry has existed.";
e_str[ERR_SEL_INVAD] = "Please select your desired entries.";

// 85500-85519	AutoPVC
e_str[ERR_AUTOPVC_VPI_INVAD] = "VPI value must be integers between 0 and 255. Please input another one.";
e_str[ERR_AUTOPVC_VCI_INVAD] = "VCI value must be integers between 0 and 65535. Please input another one.";
e_str[ERR_AUTOPVC_EXSIST_INVAD] = "This PVC has existed in PVC list.";

// 85520-85549	IPTV

// 85550-85569	ETH WAN

// 85500-85599	DSL
e_str[ERR_DSL_MODULATION_MODE_NULL] = "Please select at least one debug mode.";

// 85600-85699	Bridge
//wan
e_str[ERR_WAN_VPI_VCI_INVAD] = "Wrong configuration of VPI/VCI range.";
e_str[ERR_WAN_PCR_INVAD] = "Wrong PCR value. Please input integers between 0 and 5500.";
e_str[ERR_WAN_SCR_INVAD] = "Wrong SCR value. Please input integers between 0 and 5500.";
e_str[ERR_WAN_MBS_INVAD] = "Wrong MBS value. Please input integers between 0 and 65535.";
e_str[ERR_WAN_CONNECTIONTYPE_NULL] = "Connection type not selected.";
e_str[ERR_WAN_CONNECTIONTYPE_INVAD] = "This function is disabled for WAN port connection type.";
e_str[ERR_WAN_MTU_INVAD] = "Wrong MTU value. Please input integers between 576 and 1500.";
e_str[ERR_WAN_PPPOE_MTU_INVAD] = "Wrong MTU value. Please input integers between 576 and 1492.";
e_str[ERR_WAN_DNSADDR_INVAD] = "Wrong configuration of DNS Server address.";
e_str[ERR_WAN_SECDNS_INVAD] = "Wrong configuration of secondary DNS Server address.";
e_str[ERR_WAN_ECHOTIME_INVAD] = "Wrong configuration of on line triggering time. Please input numbers between o and 120.";
e_str[ERR_WAN_USERNAME_INVAD] = "Please input user name.";
e_str[ERR_WAN_PWD_INVAD] = "Please input password.";
e_str[ERR_WAN_DEFGATEWAY_INVAD] = "Please select a WAN port as system default gateway.";
e_str[ERR_AUTOPVC_INVAD] = "Searching PVC failed.";
e_str[ERR_AUTOPVC_IP_FORMAT] = "Please set available gateway IP when searching PVC automatically.";
e_str[ERR_GROUP_INVAD] = "No interface added or no group name!";
e_str[ERR_INTERFACE_INVAD] = "Please select an interface first.";
e_str[ERR_GROUP_NAME_INVAD] = "The group has existed. Please input another one.";
e_str[ERR_PWD_INVAD] = "The confirm password must accord with the new password!";
e_str[ERR_USERNAME_INVAD] = "Wrong user name. Please input another one."; 
e_str[ERR_WAN_SCR_EMPTY] = "SCR value can not be empty.";
e_str[ERR_WAN_PCR_EMPTY] = "PCR value can not be empty.";
e_str[ERR_WAN_SCR_LARGER_THAN_PCR] = "SCR value can not be larger than PCR value.";
e_str[ERR_WAN_INTER_GROUPNAME_INVALID] = "Illegal group name. Please input another one!";
e_str[ERR_WAN_MBS_EMPTY] = "MBS value can not be empty.";
e_str[ERR_WAN_VLANID_INVAD] = "Wrong VLAN ID value. Please input integers between 1 and 4094.";

// 85700-85799	Static IP/IPoA
e_str[ERR_STAIP_IP_INVAD] = "Illegal IP address. Please input another one.";
e_str[ERR_STAIP_MASK_INVAD] = "Illegal Subnet Mask. Please input another one.";
e_str[ERR_STAIP_GW_INVAD] = "Illegal default gateway. Please input another one.";
e_str[ERR_STAIP_IP_MASK_CONFLICT] = "IP address conflicts with Subnet Mask. Please input another one.";
e_str[ERR_STAIP_GW_MASK_CONFLICT] = "Default gateway conflicts with Subnet Mask. Please input another one.";
e_str[ERR_STAIP_IP_GW_CONFLICT] = "The default gateway doesn't belong to the net segment of IP address. Please input another one.";
e_str[ERR_STAIP_DNS1_INVAD] = "Illegal primary DNS. Please input another one.";
e_str[ERR_STAIP_DNS2_INVAD] = "Illegal secondary DNS. Please input another one.";
e_str[ERR_IPOA_PVC_INVAD] = "IPoA don't support single-PVC-multi-connection. Please set available vpi/vci.";

// 85800-85899	Dynamic IP
e_str[ERR_WAN_HOST_NAME_INVALID] = "Illegal host name. Please input another one.";
e_str[ERR_WAN_DNS_INVAD] = "You have selected configuring DNS manually. Please set at least one available DNS address.";

// 85900-85999	PPPoE/PPPoA	
e_str[ERR_IDLETIME_INVAD] = "Wrong Max Idle Time! Please enter a number between 0-99!";
e_str[ERR_PPPOA_PVC_INVAD] = "PPPoA don't support single-PVC-multi-connection. Please set available vpi/vci.";

// 86000-86000 	SNMP
e_str[ERR_SNMP_RCOMMUNITY_EMPTY]	= "Please input values for Read Community.";
e_str[ERR_SNMP_SCOMMUNITY_EMPTY]	= "Please input values for Set Community.";
e_str[ERR_SNMP_TRAP_IP_INVAD]		= "Wrong Trap Manager IP address. Please input another one."; 

//86100-86199 USB
e_str[ERR_USB_SHARE_NAME_EMPTY] 					= "The Share Name can not be blank!";
e_str[ERR_USB_SHARE_NAME_NOT_ASCII]					= "The Share Name must be ASCII characters!";
e_str[ERR_USB_INVALID_CHAR_IN_FOLDER_NAME] 			= "Invalid characters in folder name: space character or \\/:*?\"<>|]";
e_str[ERR_USB_DIR_NAME_EMPTY]						= "The Directory can not be blank!";
e_str[ERR_USB_DIR_NAME_NOT_ASCII]					= "The Directory must be ASCII characters!";
e_str[ERR_USB_DIR_EXIST]							= "The Directory already exists!";
e_str[ERR_USB_SHARE_NAME_EXIST]						= "The Share Name already exists!";
e_str[ERR_USB_DIR_NOT_EXIST]						= "The directory doesn't exist!";
e_str[ERR_USB_INVALID_CHAR_IN_USER_NAME] 			= "Invalid characters in user name: space character or \\/:*?\"<>|@+=;,.[]()$";
e_str[ERR_USB_CONFLICT_USER_NAME] 					= "The user name conflicts with another one!";
e_str[ERR_USB_FTP_PORT_EMPTY]						= "Please input the service port!";
e_str[ERR_USB_FTP_PORT_NOT_NUM]						= "The service port must be a number!";
e_str[ERR_USB_FTP_PORT_RANGE]						= "The service port is out of range!";
e_str[ERR_USB_FTP_PORT_CONFLICT]					= "The service port has already used by other service!";
e_str[ERR_USB_DLNA_SERVER_NAME_EMPTY] 				= "The Server Name can not be blank!";
e_str[ERR_USB_DLNA_SERVER_NAME_NOT_ASCII] 			= "The Server Name must be ASCII characters!";
e_str[ERR_USB_DLNA_INVALID_SERVER_NAME] 			= "Invalid characters in Server Name: space character or \\/*?\"<>|]";
//86180-86199 USB 3G
e_str[ERR_USB_3G_FILE_NONE]							= "Please choose a 3G USB modem configuration file for loading!";

// 86200-86299	IPv6
e_str[ERR_IP6_WAN_CONN_NONE]				= "No WAN connection! Please add one first.";

e_str[ERR_LAN6_PREFIX_EMPTY]				= "Please input prefix.";
e_str[ERR_LAN6_PREFIX_INVALID]				= "Invalid IPv6 site prefix! Please input another one.";
e_str[ERR_LAN6_PREFIX_LEN_EMPTY]			= "Please input prefix length.";
e_str[ERR_LAN6_PREFIX_LEN_INVALID]			= "The prefix length must be 64.";
e_str[ERR_LAN6_DHCP6S_START_ID_EMPTY]		= "Please input the start IPv6 interface ID.";
e_str[ERR_LAN6_DHCP6S_END_ID_EMPTY]			= "Please input the end IPv6 interface ID.";
e_str[ERR_LAN6_LEASE_TIME_EMPTY]			= "Please input the leased time.";
e_str[ERR_LAN6_DHCP6S_START_ID_INVALID]		= "Invalid start IPv6 interface ID! Please input a hexadecimal number in range(1-FFFF).";
e_str[ERR_LAN6_DHCP6S_END_ID_INVALID]		= "Invalid end IPv6 interface ID! Please input a hexadecimal number in range(1-FFFF).";
e_str[ERR_LAN6_LEASE_TIME_INVALID]			= "Invalid leased time! Please input an integer in range(0-999999).";
e_str[ERR_LAN6_DHCP6S_ADDR_CONFLICT]		= "Invalid input! The start interface ID is larger than the end interface ID.";

e_str[ERR_WAN6_IP_STACK_NONE]				= "Please choose one IP stack at least!";
e_str[ERR_WAN6_ADDR_INVAD]					= "Wrong format of IPv6 address!";
e_str[ERR_WAN6_PFXLEN_INVAD]				= "Please input a correct IPv6 prefix length. The value should be in range(0-128).";
e_str[ERR_WAN6_DNS_INVAD]					= "You have selected configuring IPv6 DNS manully, please set at least one available IPv6 DNS address.";

e_str[ERR_ROUTE6_DST_ADDR_VALID]			= "Please input a correct destination IPv6 address.";
e_str[ERR_ROUTE6_PREFIX_LEN_VALID]			= "Please input a correct prefix length. The value should not be larger than 64(include 64).";
e_str[ERR_ROUTE6_GW_ADDR_VALID]				= "Please input a correct gateway IPv6 address.";
e_str[ERR_ROUTE6_GW_VALID]					= "Gateway address should have the same prefix with the selected WAN interface's IPv6 address.";

e_str[ERR_TUNNEL6_DSLITE_REMOTE_INVALID]	= "Please input a correct remote IPv6 address.";
e_str[ERR_TUNNEL6_DSLITE_WAN_CONN_ERR]		= "There must be no IPv4 WAN connections in DS-Lite. Please check the WAN connections.";
e_str[ERR_TUNNEL6_6RD_PREFIX_LEN_INVALID]	= "Please input a correct 6RD prefix length. The value should be in range(1-32).";
e_str[ERR_TUNNEL6_6RD_PREFIX_INVALID]		= "Please input a correct 6RD prefix.";
e_str[ERR_TUNNEL6_6RD_BR_INVALID]			= "Please input a correct border relay IPv4 address.";
e_str[ERR_TUNNEL6_6RD_IP_MASK_LEN_INVALID]	= "Please input a correct IPv4 mask length. The value should be in range(1-32).";
e_str[ERR_TUNNEL6_6RD_NOT_SUPPORT_AUTO]		= "Only Dynamic IP WAN connection support Auto 6RD. Please change the configuration type to manual or select another connection!";
e_str[ERR_TUNNEL6_6RD_WAN_CONN_ERR]			= "There must be no IPv6 WAN connections in 6RD. Please check the WAN connections.";
e_str[ERR_TUNNEL6_6TO4_WAN_CONN_ERR]		= "There must be no IPv6 WAN connections in 6to4. Please check the WAN connections.";

e_str[ERR_FW6_ADDR_INVAD]					= "Wrong format of IPv6 address!";
e_str[ERR_FW6_PFXLEN_INVAD]					= "Invalid prefix length!";

// 87500-87999	Wireless
e_str[ERR_WLAN_SSID_IS_EMPTY]="Please input SSID.";
e_str[ERR_WLAN_SSID_LEN_OUTRANGE]="Up to 32 characters in the SSID field!";
e_str[ERR_WLAN_WDS_SSID_IS_EMPTY]="Please input Bridge SSID.";
e_str[ERR_WLAN_WDS_SSID_LEN_OUTRANGE]="Up to 32 characters in the Bridge SSID field!";
e_str[ERR_WLAN_WDS_BSSID_IS_EMPTY]="Please input Bridge BSSID.";
e_str[ERR_WLAN_WDS_BSSID_INVALID]="Wrong format of Bridge BSSID. Please check it.";
e_str[ERR_WLAN_WDS_ASCII_KEY_INVALID]="Bridge ASCII password contains illegal characters.";
e_str[ERR_WLAN_WDS_ASCII_KEY_OUTRANGE]="The length of ASCII bridge connection WEP key must be 5, 13 or 16.";
e_str[ERR_WLAN_WDS_HEX_KEY_INVALID]="The hexadecimal password of Bridge connection contains illegal characters.";
e_str[ERR_WLAN_WDS_HEX_KEY_OUTRANGE]="The length of hexadecimal bridge connection WEP key must be 10, 26 or 32. ";
e_str[ERR_WLAN_WDS_PSK_OUTRANGE]="The length of bridge connection PSK key should be ASCII characters between 8 and 63 or 64 hexadecimal characters.";
e_str[ERR_WLAN_WDS_AUTO_CHANNEL]="If WDS is enabled, channel must be set according to RootAP.";
e_str[ERR_WLAN_WDS_CHANNEL]="Connecting AP channel is $, which is different from configured AP channel. Please reset.";

e_str[ERR_WLAN_BAND_NOT_SUPPORT_5G]="The country do not support 5G,please ensure you select a correct country!";

e_str[ERR_WLAN_BEACONINTERVAL_INVAD]="Beacon interval value contains illegal characters. Please check it.";
e_str[ERR_WLAN_RTSINTERVAL_INVAD]="The RTS threshold value contains illegal characters. Please check it.";
e_str[ERR_WLAN_FRAGTH_INVAD]="Fragmentation threshold value contains illegal characters. Please check it.";
e_str[ERR_WLAN_DTIMTH_INVAD]="DTIM interval value contains illegal characters. Please check it.";
e_str[ERR_WLAN_BEACONINTERVAL_OUTRANGE]="Beacon interval value belongs to integers between 25 and 1000. Please check it.";
 
e_str[ERR_WLAN_RTSINTERVAL_OUTRANGE]="The RTS threshold value belongs to integers between 1 and 2346. Please check it.";
e_str[ERR_WLAN_FRAGTH_OUTRANGE]="Fragmentation threshold value belongs to integers between 256 and 2346. Please check it.";
e_str[ERR_WLAN_DTIMTH_OUTRANGE]="DTIM interval value belongs to integers between 1 and 255. Please check it.";

e_str[ERR_WLAN_11N_WEP_CONFLICT]="11n-only is unsupported with WEP encryption enabled.";
e_str[ERR_WLAN_11N_TKIP_CONFLICT]="11n-only is unsupported with TKIP encryption enabled.";
e_str[ERR_WLAN_QSS_WPA_CONFLICT]="WPA encryption is unsupported with WPS enabled.";
e_str[ERR_WLAN_QSS_TKIP_CONFLICT]="TKIP encryption is unsupported with WPS enabled.";
e_str[ERR_WLAN_QSS_WEP_CONFLICT]="WEP encryption is unsupported with WPS enabled.";
e_str[ERR_WLAN_MSSID_WEP_CONFLICT]="Multi SSID is unsupported with WEP encryption enabled.";

e_str[ERR_WLAN_PIN_EMPTY]="Please input PIN.";
e_str[ERR_WLAN_PIN_LEGNTH_INVALID]="Up to 8 characters in the PIN field!";
e_str[ERR_WLAN_PIN_INVALID]="PIN value must be integers!";
e_str[ERR_WLAN_PIN_CHECKSUM_FAIL]="Invalid PIN. Please check it.";
e_str[ERR_WLAN_WEP_NO_KEY]="Please make sure at least one WEP key.";
e_str[ERR_WLAN_WEP_KEY_LENGTH_INVALID]="Please input legal WEP key.";
e_str[ERR_WLAN_WEP_KEY_HEX_INVALID]="Please make sure the current key contains hexadecimal characters only.";
e_str[ERR_WLAN_WEP_KEY_ASCII_INVALID]="Please make sure the current key contains ASCII characters only.";
e_str[ERR_WLAN_WPA_PSK_EMPTY]="Please input TKIP/AES password!";
e_str[ERR_WLAN_WPA_PSK_LENGTH_INVALID]="The length of TKIP/AES password must be more than 8.";
e_str[ERR_WLAN_WPA_PSK_HEX_INVALID]="The TKIP/AES password contains hexadecimal n-hexadecimal characters.";
e_str[ERR_WLAN_WPA_PSK_ASCII_INVALID]="The TKIP/AES value contains non-ASCII characters. Please input another one.";
e_str[ERR_WLAN_WPA_INTERVAL_INVALID]="Group key renews its cycle illegally!";
e_str[ERR_WLAN_WPA_PORT_INVALID]="Please input legal RADIUS Server Port!";
e_str[ERR_WLAN_WPA_PWD_EMPTY]="Please input RADIUS Server Password!";
e_str[ERR_WLAN_WPA_PWD_INVALID]="Please input legal RADIUS Server Password!";

e_str[ERR_WLAN_MAC_LIST_EMPTY]="The list of wireless MAC filtering is empty.";
e_str[ERR_WLAN_MAC_INVALID]="Invalid MAC address. Please input another one.";
e_str[ERR_WLAN_MAC_CONFLICT]="This filtering address has existed. Please input another one.";
e_str[ERR_WLAN_MAC_FILTER_INVALID]="Configuring MAC address filter failed. Please make sure wireless function enabled!";
e_str[ERR_WLAN_MAC_FILTER_DESCRIP_INVALID]="Please input correct description! Description must not contains \'\\\/\":*?<>|&\', and must not end with blank.";
e_str[ERR_WLAN_5G_REGION_CHANGED]="Selecting the incorrect country may cause interference to other devices and violate the applicable law.";
e_str[ERR_WLAN_MODE_INVALID]="Wrong modeValue, should not be here!";

// 89000-89100 3G error
e_str[ERR_PIN_CODE_EMPTY] = "PIN code can not be empty!";
e_str[ERR_PIN_ASCII] = "PIN code must be ASCII characters!";
e_str[ ERR_PIN_CODE_CONFLICT] = "Confirm New PIN code must be the same with New PIN Code!";
e_str[ERR_3G_INVLIAD_DIALNUM] = "Invalid Dial Number. Only 0-9 and # and * can be accepted!";

// 90000-96000	HTTP protocol error
e_str[ERR_INTERNAL] = "System internal error!";
e_str[ERR_NOT_FOUND] = "File not found!";
e_str[ERR_NOT_ACCEPTED] = "File not accept!";

//120000-? IE error
e_str[ERR_NETWORK] = "Network error. Please check the network connection and the network configuration.";//95000-95500 vlan config error
e_str[ERR_WAN_VLAN_ID_CONFLICT] = "This Vlan ID has existed. Please input anther one.";
e_str[ERR_WAN_VLAN_ID_INVALID] = "Invalid Vlan ID!";